"use strict";
function sendLog(...args) {
    try {
        console.log.apply(console, args);
    }
    catch (e) { }
}
function sendError(...args) {
    try {
        console.error.apply(console, args);
    }
    catch (e) { }
}
function postToUI(msg) {
    try {
        if (reearth && reearth.ui && typeof reearth.ui.postMessage === 'function') {
            reearth.ui.postMessage(msg);
            return;
        }
    }
    catch (e) { }
    try {
        if (typeof window !== 'undefined' && window.parent && typeof window.parent.postMessage === 'function') {
            window.parent.postMessage(msg, '*');
            return;
        }
    }
    catch (e) { }
    try {
        if (typeof globalThis.parent !== 'undefined' && globalThis.parent && typeof globalThis.parent.postMessage === 'function') {
            globalThis.parent.postMessage(msg, '*');
        }
    }
    catch (e) { }
}
function encodeNonAscii(u) {
    try {
        if (!u || typeof u !== 'string')
            return u;
        return u.replace(/[\u0080-\uFFFF]/g, (c) => encodeURIComponent(c));
    }
    catch (e) {
        return u;
    }
}
function tryDecode(u) {
    try {
        return decodeURIComponent(u);
    }
    catch (e) {
        return u;
    }
}
function urlsEqual(a, b) {
    if (a === b)
        return true;
    try {
        const da = tryDecode(a || '');
        const db = tryDecode(b || '');
        if (da === db)
            return true;
        const ea = encodeNonAscii(da);
        const eb = encodeNonAscii(db);
        return ea === eb;
    }
    catch (e) {
        return false;
    }
}
function normalizeLayers(raw) {
    if (!raw)
        return [];
    if (Array.isArray(raw))
        return raw;
    if (typeof raw === 'object') {
        try {
            return Object.values(raw);
        }
        catch (e) {
            return [];
        }
    }
    return [];
}
function findLayerPanelWidgetId() {
    try {
        const list = (reearth && reearth.extension && reearth.extension.list) || [];
        const target = list.find((ex) => ex && ex.extensionId === 'layers-and-tiles-list');
        return target ? target.id : null;
    }
    catch (e) {
        return null;
    }
}
function postToLayerPanel(msg) {
    const targetId = _layerPanelId || findLayerPanelWidgetId();
    if (!targetId)
        return;
    try {
        if (reearth && reearth.extension && typeof reearth.extension.postMessage === 'function') {
            reearth.extension.postMessage(targetId, msg);
        }
    }
    catch (e) { }
}
function requestBaseList() {
    try {
        _layerPanelId = findLayerPanelWidgetId();
        if (_layerPanelId)
            postToLayerPanel({ action: 'requestBaseList' });
    }
    catch (e) { }
}
let _lastBasemapsHash = '';
let _parsedBaseTiles = [];
// null = no selection yet (auto-select first base entry); '' = user selected "(なし)"
let _lastSelectedBasemapUrl = null;
let _layerPanelId = null;
const BASEMAP_TILE_ID = 'geo-suite-basemap';
function sendBasemapsToUI() {
    try {
        const items = _parsedBaseTiles.map((b) => ({
            url: b.encodedUrl || encodeNonAscii(b.url),
            title: b.title,
            attribution: b.attribution
        }));
        let selectedUrl = (_lastSelectedBasemapUrl !== null) ? _lastSelectedBasemapUrl : (items[0] ? items[0].url : '');
        const hash = JSON.stringify(items) + '|' + selectedUrl;
        if (hash === _lastBasemapsHash)
            return;
        _lastBasemapsHash = hash;
        postToUI({ action: 'basemaps', items: items, selectedUrl: selectedUrl });
    }
    catch (e) {
        sendError('[sendBasemapsToUI] error:', e);
    }
}
// Hide legacy basemap layers added by older versions of this plugin (they were
// regular tile layers marked with data.isBasemap and rendered above overlays).
function hideLegacyBasemapLayers() {
    try {
        const all = (reearth && reearth.layers && reearth.layers.layers) ? reearth.layers.layers : [];
        const arr = normalizeLayers(all);
        arr.forEach((l) => {
            if (!l || !l.data || !l.data.isBasemap || !l.id)
                return;
            try {
                if (typeof reearth.layers.hide === 'function')
                    reearth.layers.hide(l.id);
                else if (typeof reearth.layers.override === 'function')
                    reearth.layers.override(l.id, { visible: false });
            }
            catch (e) { }
        });
    }
    catch (e) { }
}
// Switch the basemap via the viewer property `tiles` (Re:Earth's official
// basemap mechanism). Scene tiles are always kept at the BOTTOM of Cesium's
// imagery layer collection by the engine, so overlay tile layers added by the
// layer panel are never hidden — regardless of when the basemap is switched.
function showBasemapByUrl(url) {
    if (url === null || url === undefined)
        return;
    _lastSelectedBasemapUrl = url;
    try {
        const tiles = [];
        if (url !== '') {
            const entry = _parsedBaseTiles.find((b) => urlsEqual(b.encodedUrl, url) || urlsEqual(b.url, url));
            const encodedUrl = entry ? entry.encodedUrl : encodeNonAscii(url);
            const tile = { id: BASEMAP_TILE_ID, type: 'url', url: encodedUrl };
            const minL = (entry && typeof entry.minLevel === 'number' && !isNaN(entry.minLevel)) ? entry.minLevel : null;
            let maxL = (entry && typeof entry.maxLevel === 'number' && !isNaN(entry.maxLevel)) ? entry.maxLevel : null;
            if (maxL === null)
                maxL = defaultMaxLevelForUrl(encodedUrl);
            if (maxL !== null)
                tile.zoomLevelForURL = [minL !== null ? minL : 0, maxL];
            else if (minL !== null)
                tile.zoomLevelForURL = [minL];
            tiles.push(tile);
        }
        if (reearth && reearth.viewer && typeof reearth.viewer.overrideProperty === 'function') {
            reearth.viewer.overrideProperty({ tiles: tiles });
        }
        else {
            sendError('[showBasemapByUrl] reearth.viewer.overrideProperty is not available');
        }
        hideLegacyBasemapLayers();
    }
    catch (e) {
        sendError('[showBasemapByUrl] error:', e);
    }
}
function defaultMaxLevelForUrl(url) {
    try {
        if (/cyberjapandata\.gsi\.go\.jp\/xyz\/(gazo[1-4]|ort_old10|ort_riku10)\//.test(url))
            return 17;
        if (/cyberjapandata\.gsi\.go\.jp\/xyz\//.test(url))
            return 18;
        if (/tile\.openstreetmap\.org\//.test(url))
            return 19;
    }
    catch (e) { }
    return null;
}
function applyBaseList(items) {
    if (!Array.isArray(items))
        return;
    try {
        _parsedBaseTiles = items.map((b) => {
            const url = (b && b.url) ? String(b.url) : '';
            const title = (b && b.title) ? String(b.title) : '';
            const attribution = (b && b.attribution) ? String(b.attribution) : '';
            const encodedUrl = encodeNonAscii(url);
            return { url, encodedUrl, title, attribution, minLevel: (b && typeof b.minLevel === 'number') ? b.minLevel : null, maxLevel: (b && typeof b.maxLevel === 'number') ? b.maxLevel : null };
        }).filter((b) => b.url);
        if (!_parsedBaseTiles.length)
            return;
        if (_lastSelectedBasemapUrl === null && _parsedBaseTiles[0]) {
            _lastSelectedBasemapUrl = _parsedBaseTiles[0].encodedUrl;
        }
        showBasemapByUrl(_lastSelectedBasemapUrl);
        _lastBasemapsHash = '';
        sendBasemapsToUI();
    }
    catch (e) {
        sendError('[applyBaseList] error:', e);
    }
}
const html = `
  <style>
    html, body { margin: 0; padding: 0; width: 300px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
    .basemap-wrap { background-color: rgba(255, 255, 255, 0.3); padding: 5px; box-shadow: 0 2px 8px rgba(0,0,0,0.15); backdrop-filter: blur(4px); width: 291px; margin-left: 9px; box-sizing: border-box; display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
    .basemap-select { flex: 1; border: 1px solid #ccc; border-radius: 4px; padding: 6px; font-size: 0.9em; background: #fff; box-sizing: border-box; }
    .basemap-globe { flex: 0 0 auto; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; font-size: 1.1em; cursor: pointer; border: 1px solid #ccc; border-radius: 4px; background: #fff; user-select: none; }
    .basemap-globe:hover { background: #f0f4fb; }
    .basemap-attribution { font-size: 0.7em; color: #333; margin-top: 4px; min-height: 1.2em; overflow-wrap: break-word; word-break: break-word; flex-basis: 100%; }
  </style>
  <div class="basemap-wrap">
    <div id="basemap-globe" class="basemap-globe" title="Google Earth で現在の表示を開く" role="button" aria-label="Google Earth で現在の表示を開く">🌐</div>
    <select id="basemap-select" class="basemap-select">
      <option value="">(なし)</option>
    </select>
    <div id="basemap-attribution" class="basemap-attribution"></div>
  </div>
  <script>
    (function(){
      const select = document.getElementById('basemap-select');
      const attrEl = document.getElementById('basemap-attribution');
      const globeBtn = document.getElementById('basemap-globe');

      function postToParent(data) {
        try {
          if (window.parent && data) window.parent.postMessage(data, '*');
        } catch(e) {}
      }

      function requestBaseListFromUI() {
        postToParent({ action: 'requestBaseList' });
      }

      function updateAttribution() {
        try {
          const opt = select && select.options[select.selectedIndex];
          if (!opt || !attrEl) return;
          let attr = (opt && opt.dataset.attribution) ? opt.dataset.attribution : '';
          try { attr = decodeURIComponent(attr); } catch(e){}
          const div = document.createElement('div');
          div.innerHTML = attr;
          attrEl.textContent = div.textContent || div.innerText || '';
        } catch(e) {}
      }

      function renderOptions(items, selectedUrl) {
        if (!select) return;
        select.innerHTML = '';
        const noneOpt = document.createElement('option');
        noneOpt.value = '';
        noneOpt.textContent = '(なし)';
        select.appendChild(noneOpt);
        if (items && items.length > 0) {
          items.forEach(function(b) {
            const opt = document.createElement('option');
            opt.value = b.url || '';
            opt.textContent = b.title || b.url || '';
            opt.setAttribute('data-attribution', encodeURIComponent(b.attribution || ''));
            select.appendChild(opt);
          });
        }
        if (select) {
          select.value = (selectedUrl !== undefined && selectedUrl !== null) ? String(selectedUrl) : '';
        }
        updateAttribution();
      }

      if (select) {
        select.addEventListener('change', function() {
          updateAttribution();
          if (window.parent) {
            window.parent.postMessage({ action: 'selectBasemap', url: select.value }, '*');
          }
        });
        select.addEventListener('focus', function() {
          // ドロップダウンが空（(なし) だけ）の場合、レイヤーパネルに再読み込みを依頼
          if (select.options.length <= 1) {
            requestBaseListFromUI();
          }
        });
      }

      if (globeBtn) {
        globeBtn.addEventListener('click', function() {
          if (window.parent) {
            window.parent.postMessage({ action: 'openGoogleEarth' }, '*');
          }
        });
      }

      window.addEventListener('message', function(e) {
        try {
          const msg = e && e.data;
          if (!msg || !msg.action) return;
          if (msg.action === 'basemaps') {
            renderOptions(msg.items, msg.selectedUrl);
          }
        } catch(e) {}
      });

      requestBaseListFromUI();
      try {
        if (typeof setTimeout === 'function') {
          setTimeout(function() {
            if (select && select.options.length <= 1) {
              requestBaseListFromUI();
            }
          }, 3000);
          setTimeout(function() {
            if (select && select.options.length <= 1) {
              requestBaseListFromUI();
            }
          }, 10000);
        }
      } catch(e) {}
    })();
  </script>
`;
function openGoogleEarthInNewWindow() {
    try {
        const pos = (reearth && reearth.camera && reearth.camera.position) ? reearth.camera.position : null;
        if (!pos || typeof pos.lat !== 'number' || typeof pos.lng !== 'number') {
            sendLog('[openGoogleEarth] no camera position');
            return;
        }
        const cameraLat = pos.lat;
        const cameraLng = pos.lng;
        const height = (typeof pos.height === 'number' && !isNaN(pos.height)) ? Math.max(0, pos.height) : 1000;
        const headingRad = (typeof pos.heading === 'number' && !isNaN(pos.heading)) ? pos.heading : 0;
        const pitchRad = (typeof pos.pitch === 'number' && !isNaN(pos.pitch)) ? pos.pitch : -Math.PI / 2;
        // Convert Cesium/Re:Earth pitch to Google Earth tilt (nadir -PI/2 -> 0, horizon 0 -> 90)
        const tiltRad = Math.max(0, Math.min(Math.PI / 2, pitchRad + Math.PI / 2));
        const tiltDeg = tiltRad * 180 / Math.PI;
        const headingDeg = ((headingRad * 180 / Math.PI) % 360 + 360) % 360;
        // Compute the ground target point that the camera is looking at, using the same
        // back-calculation logic as KASUGAI Canvas's flyToFeature.
        const metersPerDegLat = 111320;
        const metersPerDegLng = 111320 * Math.cos(cameraLat * Math.PI / 180);
        let targetLat = cameraLat;
        let targetLng = cameraLng;
        let distance = height;
        if (tiltRad > 0.01) {
            const horizontalDistance = height * Math.tan(tiltRad);
            targetLat = cameraLat + (horizontalDistance * Math.cos(headingRad)) / metersPerDegLat;
            targetLng = cameraLng + (horizontalDistance * Math.sin(headingRad)) / (metersPerDegLng || 1);
            distance = height / Math.cos(tiltRad);
        }
        const url = `https://earth.google.com/web/@${targetLat.toFixed(6)},${targetLng.toFixed(6)},0a,${distance.toFixed(2)}d,35y,${headingDeg.toFixed(1)}h,${tiltDeg.toFixed(1)}t,0r`;
        if (reearth && reearth.viewer && typeof reearth.viewer.open === 'function') {
            reearth.viewer.open(url);
        }
        else {
            sendLog('[openGoogleEarth] reearth.viewer.open is not available');
        }
    }
    catch (e) {
        sendError('[openGoogleEarth] error:', e);
    }
}
try {
    if (typeof reearth !== 'undefined' && reearth && reearth.extension && typeof reearth.extension.on === 'function') {
        reearth.extension.on('message', (msg) => {
            try {
                if (!msg || !msg.action)
                    return;
                if (msg.action === 'requestBasemaps') {
                    sendBasemapsToUI();
                }
                else if (msg.action === 'selectBasemap') {
                    try {
                        showBasemapByUrl(typeof msg.url === 'string' ? msg.url : null);
                        // Re-sync UI after a short delay
                        if (typeof setTimeout === 'function') {
                            setTimeout(() => { sendBasemapsToUI(); }, 150);
                        }
                        else {
                            sendBasemapsToUI();
                        }
                    }
                    catch (e) {
                        sendError('[selectBasemap] error:', e);
                    }
                }
                else if (msg.action === 'openGoogleEarth') {
                    try {
                        openGoogleEarthInNewWindow();
                    }
                    catch (e) {
                        sendError('[openGoogleEarth] error:', e);
                    }
                }
                else if (msg.action === 'requestBaseList') {
                    try {
                        requestBaseList();
                    }
                    catch (e) {
                        sendError('[requestBaseList] error:', e);
                    }
                }
            }
            catch (e) { }
        });
    }
}
catch (e) { }
try {
    if (typeof reearth !== 'undefined' && reearth && reearth.extension && typeof reearth.extension.on === 'function') {
        reearth.extension.on('extensionMessage', (msg) => {
            try {
                const data = (msg && msg.data !== undefined) ? msg.data : msg;
                if (!data || !data.action)
                    return;
                if (data.action === 'baseList') {
                    applyBaseList(data.items);
                }
                else if (data.action === 'requestBaseList') {
                    // If asked by layer panel (unexpected direction), respond with current list
                    _layerPanelId = msg.sender || _layerPanelId;
                    if (_parsedBaseTiles.length) {
                        try {
                            if (reearth && reearth.extension && typeof reearth.extension.postMessage === 'function' && _layerPanelId) {
                                reearth.extension.postMessage(_layerPanelId, { action: 'baseList', items: _parsedBaseTiles });
                            }
                        }
                        catch (e) { }
                    }
                }
            }
            catch (e) { }
        });
    }
}
catch (e) { }
try {
    if (typeof reearth !== 'undefined' && reearth && reearth.ui && typeof reearth.ui.show === 'function') {
        reearth.ui.show(html, { width: 300, visible: true, position: 'bottom-left' });
    }
}
catch (e) { }
