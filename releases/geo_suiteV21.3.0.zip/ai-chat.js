"use strict";
const AI_DEBUG = false;
function aiLog(...args) {
    try {
        if (AI_DEBUG)
            console.log.apply(console, args);
    }
    catch (e) { }
}
function aiError(...args) {
    try {
        console.error.apply(console, args);
    }
    catch (e) { }
}
function postToUI(msg) {
    try {
        if (reearth && reearth.ui && typeof reearth.ui.postMessage === 'function') {
            reearth.ui.postMessage(msg);
            return;
        }
    }
    catch (e) { }
    try {
        if (typeof window !== 'undefined' && window.parent && typeof window.parent.postMessage === 'function') {
            window.parent.postMessage(msg, '*');
        }
    }
    catch (e) { }
}
function normalizeLayers(raw) {
    if (!raw)
        return [];
    if (Array.isArray(raw))
        return raw;
    if (typeof raw === 'object') {
        try {
            return Object.values(raw);
        }
        catch (e) {
            return [];
        }
    }
    return [];
}
function encodeNonAscii(u) {
    try {
        if (!u || typeof u !== 'string')
            return u;
        return u.replace(/[\u0080-\uFFFF]/g, (c) => encodeURIComponent(c));
    }
    catch (e) {
        return u;
    }
}
function defaultMaxLevelForUrl(url) {
    try {
        if (/cyberjapandata\.gsi\.go\.jp\/xyz\/(gazo[1-4]|ort_old10|ort_riku10)\//.test(url))
            return 17;
        if (/cyberjapandata\.gsi\.go\.jp\/xyz\//.test(url))
            return 18;
        if (/tile\.openstreetmap\.org\//.test(url))
            return 19;
    }
    catch (e) { }
    return null;
}
// ---------- extension wiring ----------
function findWidgetId(extensionId) {
    try {
        const list = (reearth && reearth.extension && reearth.extension.list) || [];
        const target = list.find((ex) => ex && ex.extensionId === extensionId);
        return target ? target.id : null;
    }
    catch (e) {
        return null;
    }
}
let _layerPanelId = null;
function postToLayerPanel(msg) {
    try {
        const targetId = _layerPanelId || findWidgetId('layers-and-tiles-list');
        if (!targetId)
            return false;
        _layerPanelId = targetId;
        if (reearth && reearth.extension && typeof reearth.extension.postMessage === 'function') {
            reearth.extension.postMessage(targetId, msg);
            return true;
        }
    }
    catch (e) { }
    return false;
}
// Tools executed by the layer panel widget (it owns inspector-bound state).
const PANEL_TOOLS = [
    'listCameraPresets', 'flyToPreset',
    'listBasemaps', 'setBasemap',
    'listFlyPaths', 'playFlyPath', 'stopFly',
    'setTerrain', 'setShadow',
    'openStreetView', 'flyToFeature',
    'vectorSearch', 'setFlySettings', 'searchPlaces', 'addFlatGeobufLayer', 'addParquetLayer', 'addDuckDbLayer',
    'setLayerVisible', 'addGeoJsonLayer', 'addTileLayer', 'add3dTilesLayer', 'removeLayer',
    'createFlyPath', 'deleteFlyPath',
    'showPanel', 'showInfo', 'listLegends', 'showFeatureAttributes',
    'getInspectorText', 'applyInspectorText',
    'setDepthTest', 'setGeojsonDrape', 'setBackground'
];
// Panel tools that still work (degraded) without the layer panel.
const LOCAL_FALLBACK = ['setLayerVisible', 'addGeoJsonLayer', 'addTileLayer', 'add3dTilesLayer', 'removeLayer'];
// Tools executed locally in this extension context (mirrors execLocalTool's
// switch; kept in sync manually — used by the bridge "describe" catalog).
const LOCAL_TOOLS = ['getCamera', 'flyTo', 'listLayers', 'setLayerVisible', 'focusLayer',
    'addGeoJsonLayer', 'addTileLayer', 'add3dTilesLayer', 'removeLayer', 'captureView',
    'getShareUrl', 'buildShareUrl', 'setCamera', 'lookAt', 'zoomIn', 'zoomOut', 'openUrl'];
// reqIds currently forwarded to the layer panel; extensionMessage replies are routed back to the UI.
const _pendingForward = {};
// Layer IDs added by AI tools (removeLayer is restricted to these).
const _aiAddedLayerIds = new Set();
// Inspector-provided config (forwarded from the layer panel).
let _inspectorGeminiApiKey = null;
let _inspectorAiHub = null; // optional aiHub: endpoint (CANVAS bridge-hub) from inspector
let _inspectorGeminiModel = null;
let _inspectorYahooAppId = null;
let _inspectorGoogleMapsApiKey = null;
let _inspectorLang = 'auto';
// Session-only key: kept in extension memory, never written to clientStorage.
let _sessionGeminiApiKey = null;
const AI_STORAGE_KEY = 'geminiApiKey';
const AI_STORAGE_MODEL = 'geminiModel';
const AI_STORAGE_PROVIDER = 'aiProvider';
const AI_DEFAULT_MODEL = 'gemini-3.1-flash-lite';
let _sessionAiProvider = null;
async function sendConfig() {
    let storedKey = null;
    let storedModel = null;
    let storedProvider = null;
    try {
        if (reearth && reearth.data && reearth.data.clientStorage && typeof reearth.data.clientStorage.getAsync === 'function') {
            storedKey = await reearth.data.clientStorage.getAsync(AI_STORAGE_KEY);
            storedModel = await reearth.data.clientStorage.getAsync(AI_STORAGE_MODEL);
            storedProvider = await reearth.data.clientStorage.getAsync(AI_STORAGE_PROVIDER);
        }
    }
    catch (e) { }
    let provider = null;
    try {
        const raw = _sessionAiProvider || storedProvider;
        provider = (typeof raw === 'object' && raw) ? raw : (typeof raw === 'string' && raw ? JSON.parse(raw) : null);
    }
    catch (e) { }
    // Fields declared in this extension's own schema (editable in the inspector).
    // They take precedence over the layer panel's inspectorText geminiApiKey/geminiModel lines.
    let schemaKey = '';
    let schemaModel = '';
    try {
        const prop = (reearth && reearth.extension && reearth.extension.widget && reearth.extension.widget.property)
            || (reearth && reearth.extension && reearth.extension.block && reearth.extension.block.property) || {};
        const s = (prop && prop.settings && typeof prop.settings === 'object') ? prop.settings : prop;
        if (s && typeof s.geminiApiKey === 'string')
            schemaKey = s.geminiApiKey.trim();
        if (s && typeof s.geminiModel === 'string')
            schemaModel = s.geminiModel.trim();
    }
    catch (e) { }
    const inspectorKey = schemaKey || _inspectorGeminiApiKey;
    const key = inspectorKey || _sessionGeminiApiKey || (typeof storedKey === 'string' ? storedKey : '');
    const model = schemaModel || _inspectorGeminiModel || (typeof storedModel === 'string' && storedModel ? storedModel : AI_DEFAULT_MODEL);
    postToUI({
        action: 'aiConfig',
        apiKey: key,
        hasKey: !!key,
        keySource: inspectorKey ? 'inspector' : (_sessionGeminiApiKey ? 'session' : (storedKey ? 'storage' : 'none')),
        model: model,
        provider: provider,
        aiHub: _inspectorAiHub || '',
        yahooAppId: _inspectorYahooAppId || '',
        googleMapsApiKey: _inspectorGoogleMapsApiKey || '',
        i18n: AI_I18N,
        lang: _inspectorLang || 'auto'
    });
}
// ---------- camera helpers ----------
function getCameraPos() {
    let cur = null;
    try {
        cur = (reearth.camera && typeof reearth.camera.position === 'object' && reearth.camera.position) ? reearth.camera.position : null;
    }
    catch (e) { }
    if (!cur)
        try {
            cur = (reearth.camera && typeof reearth.camera.getCamera === 'function') ? reearth.camera.getCamera() : null;
        }
        catch (e) { }
    if (!cur)
        try {
            cur = (reearth.viewer && typeof reearth.viewer.getCamera === 'function') ? reearth.viewer.getCamera() : null;
        }
        catch (e) { }
    return cur;
}
function rad2deg(r) {
    return (typeof r === 'number' && isFinite(r)) ? Math.round(r * 180 / Math.PI * 100000) / 100000 : null;
}
function cameraResult() {
    var _a, _b, _c, _d, _e, _f, _g;
    const c = getCameraPos();
    if (!c)
        return { error: 'camera unavailable' };
    const out = {};
    const lat = (_a = c.lat) !== null && _a !== void 0 ? _a : c.latitude;
    const lng = (_c = (_b = c.lng) !== null && _b !== void 0 ? _b : c.longitude) !== null && _c !== void 0 ? _c : c.lon;
    const h = (_e = (_d = c.height) !== null && _d !== void 0 ? _d : c.altitude) !== null && _e !== void 0 ? _e : c.alt;
    if (typeof lat === 'number')
        out.lat = Math.round(lat * 1000000) / 1000000;
    if (typeof lng === 'number')
        out.lng = Math.round(lng * 1000000) / 1000000;
    if (typeof h === 'number')
        out.height = Math.round(h * 10) / 10;
    const hd = rad2deg((_f = c.heading) !== null && _f !== void 0 ? _f : c.yaw);
    const pt = rad2deg((_g = c.pitch) !== null && _g !== void 0 ? _g : c.tilt);
    const rl = rad2deg(c.roll);
    if (hd !== null)
        out.heading = hd;
    if (pt !== null)
        out.pitch = pt;
    if (rl !== null)
        out.roll = rl;
    return out;
}
// ---------- local tool implementations ----------
function aiResolveLayer(ref) {
    try {
        if (ref === undefined || ref === null)
            return null;
        const all = normalizeLayers(reearth && reearth.layers && reearth.layers.layers);
        const r = String(ref);
        let l = all.find((x) => x && x.id === r);
        if (l)
            return l;
        const rl = r.toLowerCase();
        l = all.find((x) => x && String(x.title || '').toLowerCase() === rl);
        if (l)
            return l;
        l = all.find((x) => x && String(x.title || '').toLowerCase().indexOf(rl) >= 0);
        return l || null;
    }
    catch (e) {
        return null;
    }
}
function aiFlyTo(args) {
    const lat = Number(args && args.lat);
    const lng = Number(args && args.lng);
    if (!isFinite(lat) || !isFinite(lng))
        return { error: 'lat/lng required' };
    const cur = getCameraPos() || {};
    const dest = { lat: lat, lng: lng };
    dest.height = isFinite(Number(args.height)) ? Number(args.height) : (typeof cur.height === 'number' ? cur.height : 2000);
    const hd = isFinite(Number(args.heading)) ? Number(args.heading) * Math.PI / 180 : (typeof cur.heading === 'number' ? cur.heading : 0);
    const pt = isFinite(Number(args.pitch)) ? Number(args.pitch) * Math.PI / 180 : (typeof cur.pitch === 'number' ? cur.pitch : -Math.PI / 4);
    dest.heading = hd;
    dest.pitch = pt;
    dest.roll = (typeof cur.roll === 'number') ? cur.roll : 0;
    const duration = isFinite(Number(args.duration)) ? Math.max(0, Number(args.duration)) : 2;
    try {
        reearth.camera.flyTo(dest, { duration: duration });
        return { ok: true, lat: lat, lng: lng, height: dest.height };
    }
    catch (e) {
        return { error: 'flyTo failed: ' + String(e) };
    }
}
function aiListLayers() {
    const all = normalizeLayers(reearth && reearth.layers && reearth.layers.layers);
    const out = all.slice(0, 200).map((l) => ({
        id: l && l.id,
        title: (l && (l.title || (l.layer && l.layer.title))) || '',
        type: (l && l.data && l.data.type) || '',
        visible: !!(l && l.visible !== false),
        isBasemap: !!(l && l.data && l.data.isBasemap)
    }));
    return { layers: out, count: all.length };
}
function aiSetLayerVisible(args) {
    const l = aiResolveLayer(args && args.layer);
    if (!l || !l.id)
        return { error: 'layer not found: ' + String(args && args.layer) };
    const visible = !!(args && args.visible);
    try {
        if (visible) {
            if (typeof reearth.layers.hide === 'function') {
                try {
                    reearth.layers.hide(l.id);
                }
                catch (e) { }
            }
            if (typeof reearth.layers.show === 'function')
                reearth.layers.show(l.id);
            else if (typeof reearth.layers.override === 'function')
                reearth.layers.override(l.id, { visible: true });
        }
        else {
            if (typeof reearth.layers.hide === 'function')
                reearth.layers.hide(l.id);
            else if (typeof reearth.layers.override === 'function')
                reearth.layers.override(l.id, { visible: false });
        }
        return { ok: true, id: l.id, title: l.title, visible: visible };
    }
    catch (e) {
        return { error: 'setLayerVisible failed: ' + String(e) };
    }
}
function aiFocusLayer(args) {
    const l = aiResolveLayer(args && args.layer);
    if (!l || !l.id)
        return { error: 'layer not found: ' + String(args && args.layer) };
    try {
        reearth.camera.flyTo(l.id, { duration: 2 });
        return { ok: true, id: l.id, title: l.title };
    }
    catch (e) {
        return { error: 'focusLayer failed: ' + String(e) };
    }
}
function aiAddLayer(args, type) {
    const url = String((args && args.url) || '').trim();
    if (!/^https?:\/\//i.test(url) && !/^data:/i.test(url))
        return { error: 'url must be http(s)' };
    const encodedUrl = encodeNonAscii(url);
    const title = String((args && args.title) || url);
    const layer = {
        type: 'simple',
        title: title,
        visible: true,
        data: { type: type, url: encodedUrl }
    };
    if (type === 'tiles') {
        layer.tiles = {};
        const minL = isFinite(Number(args && args.minLevel)) ? Number(args.minLevel) : null;
        let maxL = isFinite(Number(args && args.maxLevel)) ? Number(args.maxLevel) : null;
        if (maxL === null)
            maxL = defaultMaxLevelForUrl(encodedUrl);
        const raster = {};
        if (minL !== null)
            raster.minimumLevel = minL;
        if (maxL !== null)
            raster.maximumLevel = maxL;
        if (minL !== null || maxL !== null)
            layer.raster = raster;
    }
    if (type === 'geojson') {
        layer.marker = { pointColor: '#3388ff', pointSize: 10 };
        layer.polyline = { strokeColor: '#3388ff', strokeWidth: 2, clampToGround: true, classificationType: 'terrain' };
        layer.polygon = { fillColor: '#3388ff44', strokeColor: '#3388ff', strokeWidth: 2, heightReference: 'clamp', classificationType: 'terrain' };
    }
    try {
        const id = reearth.layers.add(layer);
        if (id) {
            try {
                _aiAddedLayerIds.add(id);
            }
            catch (e) { }
        }
        if (args && args.visible === false && id) {
            try {
                if (typeof reearth.layers.hide === 'function')
                    reearth.layers.hide(id);
            }
            catch (e) { }
        }
        return { ok: true, id: id, title: title };
    }
    catch (e) {
        return { error: 'layers.add failed: ' + String(e) };
    }
}
function aiRemoveLayer(args) {
    const l = aiResolveLayer(args && args.layer);
    if (!l || !l.id)
        return { error: 'layer not found: ' + String(args && args.layer) };
    if (!_aiAddedLayerIds.has(l.id)) {
        return { error: 'only layers added by the AI can be removed' };
    }
    try {
        if (typeof reearth.layers.delete === 'function')
            reearth.layers.delete(l.id);
        else if (typeof reearth.layers.remove === 'function')
            reearth.layers.remove(l.id);
        else
            return { error: 'layers.delete unavailable' };
        try {
            _aiAddedLayerIds.delete(l.id);
        }
        catch (e) { }
        return { ok: true, id: l.id, title: l.title };
    }
    catch (e) {
        return { error: 'removeLayer failed: ' + String(e) };
    }
}
function aiCaptureView() {
    try {
        if (reearth.viewer && typeof reearth.viewer.capture === 'function') {
            const dataUrl = reearth.viewer.capture('image/png');
            if (dataUrl)
                return { ok: true, dataUrl: dataUrl };
            return { error: 'capture returned empty' };
        }
        return { error: 'viewer.capture unavailable' };
    }
    catch (e) {
        return { error: 'capture failed: ' + String(e) };
    }
}
function aiShareUrl() {
    const c = cameraResult();
    if (c.error)
        return c;
    const params = [];
    if (typeof c.lat === 'number')
        params.push('lat=' + c.lat);
    if (typeof c.lng === 'number')
        params.push('lng=' + c.lng);
    if (typeof c.height === 'number')
        params.push('height=' + c.height);
    if (typeof c.heading === 'number')
        params.push('heading=' + c.heading);
    if (typeof c.pitch === 'number')
        params.push('pitch=' + c.pitch);
    return { ok: true, query: '?' + params.join('&') };
}
// Permalink query for an arbitrary viewpoint (port of kasugai buildShareUrl).
// The plugin cannot read the page URL, so only the query part is produced —
// same convention as getShareUrl.
function aiBuildShareUrl(args) {
    const lat = Number(args && args.lat);
    const lng = Number(args && args.lng);
    if (!isFinite(lat) || !isFinite(lng))
        return { error: 'lat/lng required' };
    const params = ['lat=' + lat, 'lng=' + lng];
    ['height', 'heading', 'pitch'].forEach((k) => {
        const v = Number(args[k]);
        if (isFinite(v))
            params.push(k + '=' + v);
    });
    return { ok: true, query: '?' + params.join('&'), note: 'append this query to the site URL; opening ?lat=..&lng=.. restores the view' };
}
function aiSetCamera(args) {
    const lat = Number(args && args.lat);
    const lng = Number(args && args.lng);
    if (!isFinite(lat) || !isFinite(lng))
        return { error: 'lat/lng required' };
    const cur = getCameraPos() || {};
    const dest = { lat: lat, lng: lng };
    dest.height = isFinite(Number(args.height)) ? Number(args.height) : (typeof cur.height === 'number' ? cur.height : 2000);
    dest.heading = isFinite(Number(args.heading)) ? Number(args.heading) * Math.PI / 180 : (typeof cur.heading === 'number' ? cur.heading : 0);
    dest.pitch = isFinite(Number(args.pitch)) ? Number(args.pitch) * Math.PI / 180 : (typeof cur.pitch === 'number' ? cur.pitch : -Math.PI / 4);
    dest.roll = isFinite(Number(args.roll)) ? Number(args.roll) * Math.PI / 180 : (typeof cur.roll === 'number' ? cur.roll : 0);
    try {
        reearth.camera.setView(dest);
        return { ok: true, lat: lat, lng: lng };
    }
    catch (e) {
        return { error: 'setView failed: ' + String(e) };
    }
}
function aiLookAt(args) {
    const lat = Number(args && args.lat);
    const lng = Number(args && args.lng);
    if (!isFinite(lat) || !isFinite(lng))
        return { error: 'lat/lng required' };
    if (!reearth.camera || typeof reearth.camera.lookAt !== 'function')
        return { error: 'camera.lookAt unavailable' };
    const dest = { lat: lat, lng: lng };
    if (isFinite(Number(args.height)))
        dest.height = Number(args.height);
    if (isFinite(Number(args.heading)))
        dest.heading = Number(args.heading) * Math.PI / 180;
    if (isFinite(Number(args.pitch)))
        dest.pitch = Number(args.pitch) * Math.PI / 180;
    if (isFinite(Number(args.range)))
        dest.range = Number(args.range);
    // The viewer builds a BoundingSphere from `radius`; without it lookAt is a no-op.
    dest.radius = isFinite(Number(args.radius)) ? Number(args.radius)
        : (isFinite(Number(args.range)) ? Number(args.range) : 500);
    const opts = {};
    if (args.instant)
        opts.withoutAnimation = true;
    else if (isFinite(Number(args.duration)))
        opts.duration = Number(args.duration);
    try {
        reearth.camera.lookAt(dest, opts);
        return { ok: true, lat: lat, lng: lng };
    }
    catch (e) {
        return { error: 'lookAt failed: ' + String(e) };
    }
}
function aiZoom(args, dir) {
    const amt = isFinite(Number(args && args.amount)) ? Number(args.amount) : 2;
    const fn = dir === 'in' ? reearth.camera && reearth.camera.zoomIn : reearth.camera && reearth.camera.zoomOut;
    if (typeof fn !== 'function')
        return { error: 'camera.zoom' + (dir === 'in' ? 'In' : 'Out') + ' unavailable' };
    try {
        fn.call(reearth.camera, amt);
        return { ok: true, direction: dir, amount: amt };
    }
    catch (e) {
        return { error: 'zoom failed: ' + String(e) };
    }
}
function aiOpenUrl(args) {
    const url = String((args && args.url) || '').trim();
    if (!/^https?:\/\//i.test(url))
        return { error: 'url must be http(s)' };
    try {
        if (reearth.viewer && typeof reearth.viewer.open === 'function') {
            reearth.viewer.open(url);
            return { ok: true, url: url, note: 'browser may block popups not triggered by a user gesture' };
        }
        return { error: 'viewer.open unavailable' };
    }
    catch (e) {
        return { error: 'open failed: ' + String(e) };
    }
}
// Synchronous on purpose: microtask continuations scheduled during an
// extensionMessage dispatch are not pumped until the next event in the
// QuickJS host, so replying via promise .then() can stall bridge calls.
function execLocalTool(name, args) {
    try {
        switch (name) {
            case 'getCamera': return cameraResult();
            case 'flyTo': return aiFlyTo(args);
            case 'listLayers': return aiListLayers();
            case 'setLayerVisible': return aiSetLayerVisible(args);
            case 'focusLayer': return aiFocusLayer(args);
            case 'addGeoJsonLayer': return aiAddLayer(args, 'geojson');
            case 'addTileLayer': return aiAddLayer(args, 'tiles');
            case 'add3dTilesLayer': return aiAddLayer(args, '3dtiles');
            case 'removeLayer': return aiRemoveLayer(args);
            case 'captureView': return aiCaptureView();
            case 'getShareUrl': return aiShareUrl();
            case 'buildShareUrl': return aiBuildShareUrl(args);
            case 'setCamera': return aiSetCamera(args);
            case 'lookAt': return aiLookAt(args);
            case 'zoomIn': return aiZoom(args, 'in');
            case 'zoomOut': return aiZoom(args, 'out');
            case 'openUrl': return aiOpenUrl(args);
            default: return { error: 'unknown tool: ' + name };
        }
    }
    catch (e) {
        return { error: String((e && e.message) || e) };
    }
}
// Bridge catalog (describe): the tool set reachable through the external
// bridge channel. runCode executes in the bridge host iframe (basemap-widget).
function bridgeToolCatalog() {
    return {
        plugin: 'geo_suite',
        local: LOCAL_TOOLS.slice(),
        panel: PANEL_TOOLS.slice(),
        bridge: ['describe', 'runCode', 'canvasApi'],
        chat: ['aiChatSend', 'aiChatStatus', 'aiChatSet'],
        note: 'Arg schemas match the Gemini functionDeclarations (TOOL_DECLS). Flight tools (flyToPreset/flyToFeature/showFeatureAttributes) reply after arrival; pass wait:false for an immediate ack.'
    };
}
// Shared dispatch for aiToolCall (chat UI) and bridgeCall (external harness).
// reply(result) routes the result back through the caller's channel.
function dispatchToolCall(reqId, name, args, reply) {
    try {
        if (name === 'describe') {
            reply(bridgeToolCatalog());
            return;
        }
        if (name === 'removeLayer') {
            const rl = aiResolveLayer(args.layer);
            if (!rl || !rl.id || !_aiAddedLayerIds.has(rl.id)) {
                reply({ error: 'only layers added by the AI can be removed' });
                return;
            }
            args._layerId = rl.id;
        }
        // AI chat panel control — round-trips through our own UI iframe.
        if (name === 'aiChatSend' || name === 'aiChatStatus' || name === 'aiChatSet') {
            _pendingForward[reqId] = { name: name, reply: reply };
            postToUI({ action: 'aiChatCmd', reqId: reqId, cmd: name, args: args });
            return;
        }
        if (PANEL_TOOLS.indexOf(name) >= 0) {
            _pendingForward[reqId] = { name: name, reply: reply };
            const sent = postToLayerPanel({ action: 'aiToolRequest', reqId: reqId, name: name, args: args });
            if (!sent) {
                delete _pendingForward[reqId];
                if (LOCAL_FALLBACK.indexOf(name) >= 0) {
                    replyLocal(name, args);
                }
                else {
                    reply({ error: 'layer panel unavailable' });
                }
            }
        }
        else {
            replyLocal(name, args);
        }
    }
    catch (e) {
        reply({ error: String((e && e.message) || e) });
    }
    function replyLocal(n, a) {
        try {
            const v = execLocalTool(n, a);
            if (v && typeof v.then === 'function')
                v.then(reply);
            else
                reply(v);
        }
        catch (e) {
            reply({ error: String((e && e.message) || e) });
        }
    }
}
// ---------- message handlers ----------
try {
    if (reearth && reearth.extension && typeof reearth.extension.on === 'function') {
        reearth.extension.on('message', (msg) => {
            try {
                if (!msg || !msg.action)
                    return;
                if (msg.action === 'aiToolCall') {
                    const reqId = msg.reqId;
                    dispatchToolCall(reqId, String(msg.name || ''), msg.args || {}, (result) => {
                        postToUI({ action: 'aiToolResult', reqId: reqId, result: result });
                    });
                }
                else if (msg.action === 'aiGetConfig') {
                    // Ask the layer panel for inspector-provided values, then reply with merged config.
                    try {
                        postToLayerPanel({ action: 'requestAiConfig' });
                    }
                    catch (e) { }
                    sendConfig();
                }
                else if (msg.action === 'aiSetApiKey') {
                    const key = (typeof msg.key === 'string') ? msg.key.trim() : '';
                    try {
                        if (msg.persist === false) {
                            // Session-only: keep in extension memory, clear any persisted copy.
                            _sessionGeminiApiKey = key || null;
                            if (reearth.data && reearth.data.clientStorage && typeof reearth.data.clientStorage.setAsync === 'function') {
                                reearth.data.clientStorage.setAsync(AI_STORAGE_KEY, '');
                            }
                        }
                        else {
                            _sessionGeminiApiKey = null;
                            if (reearth.data && reearth.data.clientStorage && typeof reearth.data.clientStorage.setAsync === 'function') {
                                reearth.data.clientStorage.setAsync(AI_STORAGE_KEY, key);
                            }
                        }
                    }
                    catch (e) { }
                    sendConfig();
                }
                else if (msg.action === 'aiSetModel') {
                    const m = (typeof msg.model === 'string') ? msg.model.trim() : '';
                    try {
                        if (reearth.data && reearth.data.clientStorage && typeof reearth.data.clientStorage.setAsync === 'function') {
                            reearth.data.clientStorage.setAsync(AI_STORAGE_MODEL, m);
                        }
                    }
                    catch (e) { }
                    sendConfig();
                }
                else if (msg.action === 'aiChatResult' && msg.reqId && _pendingForward[msg.reqId]) {
                    const meta = _pendingForward[msg.reqId];
                    delete _pendingForward[msg.reqId];
                    if (meta && typeof meta.reply === 'function')
                        meta.reply(msg.result);
                }
                else if (msg.action === 'aiSetProvider') {
                    const pv = (msg.provider && typeof msg.provider === 'object') ? msg.provider : null;
                    try {
                        if (msg.persist === false) {
                            _sessionAiProvider = pv;
                            if (reearth.data && reearth.data.clientStorage && typeof reearth.data.clientStorage.setAsync === 'function') {
                                reearth.data.clientStorage.setAsync(AI_STORAGE_PROVIDER, '');
                            }
                        }
                        else {
                            _sessionAiProvider = null;
                            if (reearth.data && reearth.data.clientStorage && typeof reearth.data.clientStorage.setAsync === 'function') {
                                reearth.data.clientStorage.setAsync(AI_STORAGE_PROVIDER, pv ? JSON.stringify(pv) : '');
                            }
                        }
                    }
                    catch (e) { }
                    sendConfig();
                }
            }
            catch (e) { }
        });
    }
}
catch (e) { }
try {
    if (reearth && reearth.extension && typeof reearth.extension.on === 'function') {
        reearth.extension.on('extensionMessage', (msg) => {
            try {
                const data = (msg && msg.data !== undefined) ? msg.data : msg;
                if (!data || !data.action)
                    return;
                if (data.action === 'aiToolResult' && data.reqId && _pendingForward[data.reqId]) {
                    const meta = _pendingForward[data.reqId];
                    delete _pendingForward[data.reqId];
                    try {
                        const r = data.result;
                        if (meta && meta.name === 'removeLayer') {
                            if (r && !r.error && r.id)
                                _aiAddedLayerIds.delete(r.id);
                        }
                        else if (meta && (meta.name === 'addGeoJsonLayer' || meta.name === 'addTileLayer' || meta.name === 'add3dTilesLayer' || meta.name === 'addFlatGeobufLayer' || meta.name === 'addParquetLayer' || meta.name === 'addDuckDbLayer')) {
                            if (r && r.id)
                                _aiAddedLayerIds.add(r.id);
                        }
                    }
                    catch (e) { }
                    if (meta && typeof meta.reply === 'function')
                        meta.reply(data.result);
                    else
                        postToUI({ action: 'aiToolResult', reqId: data.reqId, result: data.result });
                }
                else if (data.action === 'bridgeCall') {
                    // External bridge request (relayed by the basemap-widget host iframe
                    // from a local harness). The result goes back to the requesting
                    // widget instead of our own UI iframe.
                    const replyTo = (msg && msg.sender) ? String(msg.sender) : null;
                    const bReqId = data.reqId;
                    dispatchToolCall(bReqId, String(data.name || ''), data.args || {}, (result) => {
                        try {
                            if (replyTo && reearth.extension && typeof reearth.extension.postMessage === 'function') {
                                reearth.extension.postMessage(replyTo, { action: 'bridgeResult', reqId: bReqId, result: result });
                            }
                        }
                        catch (e) { }
                    });
                }
                else if (data.action === 'aiConfig') {
                    _inspectorGeminiApiKey = (typeof data.geminiApiKey === 'string' && data.geminiApiKey) ? data.geminiApiKey : null;
                    _inspectorAiHub = (typeof data.aiHub === 'string' && data.aiHub) ? data.aiHub : null;
                    _inspectorGeminiModel = (typeof data.geminiModel === 'string' && data.geminiModel) ? data.geminiModel : null;
                    _inspectorYahooAppId = (typeof data.yahooAppId === 'string' && data.yahooAppId) ? data.yahooAppId : null;
                    _inspectorGoogleMapsApiKey = (typeof data.googleMapsApiKey === 'string' && data.googleMapsApiKey) ? data.googleMapsApiKey : null;
                    _inspectorLang = (typeof data.lang === 'string' && data.lang) ? data.lang : 'auto';
                    sendConfig();
                }
                else if (data.action === 'lang') {
                    _inspectorLang = (typeof data.lang === 'string' && data.lang) ? data.lang : 'auto';
                    postToUI({ action: 'lang', lang: _inspectorLang });
                }
            }
            catch (e) { }
        });
    }
}
catch (e) { }
// Request inspector config once at startup (layer panel may reply asynchronously).
try {
    postToLayerPanel({ action: 'requestAiConfig' });
}
catch (e) { }
// ---------- chat UI (runs in the widget iframe) ----------
// iframe i18n dictionary — delivered via aiConfig.i18n (kept out of the
// html template because the widget html transport truncates at ~54.3KB).
const AI_I18N = {
    en: { title: 'AI Chat', settings: 'Settings', clear: 'Clear chat', apiKey: 'Gemini API key', apiKeyPh: 'AIza... (stored in plugin storage)', model: 'Model', save: 'Save', saved: 'Saved', send: 'Send', inputPh: 'Ask about the map...', welcome: 'Ask me to fly somewhere, search places, or toggle layers.', noKey: 'No API key — open settings (gear) to add one.', noKeySet: 'key not set', keySet: 'key set', tool: 'tool', err: 'Error', cleared: 'Chat cleared.', timeout: 'Tool timed out', noResponse: '(no response)', stepLimit: '(tool step limit reached)', keyWarn: 'Note: the key is stored in this browser and sent to Google in page requests — it can be seen in devtools. Restrict it in Google Cloud. Do not set geminiApiKey: in the inspector on public sites.', remember: 'Save key on this browser', keySrc: 'Key source', minimize: 'Minimize', restore: 'Restore' },
    ja: { title: 'AIチャット', settings: '設定', clear: 'チャットをクリア', apiKey: 'Gemini APIキー', apiKeyPh: 'AIza...（プラグインストレージに保存）', model: 'モデル', save: '保存', saved: '保存しました', send: '送信', inputPh: '地図について聞く...', welcome: '場所への移動・地名検索・レイヤー操作などを頼んでください。', noKey: 'APIキー未設定 — 歯車から設定してください。', noKeySet: 'キー未設定', keySet: 'キー設定済み', tool: 'ツール', err: 'エラー', cleared: 'チャットをクリアしました。', timeout: 'ツールがタイムアウトしました', noResponse: '（応答なし）', stepLimit: '（ツール実行の上限に達しました）', keyWarn: '注意：キーはこのブラウザに保存され、ページのリクエストでGoogleに送信されます — DevToolsで閲覧可能です。Google Cloudでキーを制限してください。公開サイトではインスペクターに geminiApiKey: を書かないでください。', remember: 'このブラウザにキーを保存', keySrc: 'キーの出所', minimize: '最小化', restore: '元に戻す' },
    'zh-CN': { title: 'AI 聊天', settings: '设置', clear: '清空聊天', apiKey: 'Gemini API 密钥', apiKeyPh: 'AIza...（保存于插件存储）', model: '模型', save: '保存', saved: '已保存', send: '发送', inputPh: '询问地图相关...', welcome: '可以让我飞到某地、搜索地点或切换图层。', noKey: '未设置 API 密钥 — 请在齿轮设置中添加。', noKeySet: '未设密钥', keySet: '密钥已设', tool: '工具', err: '错误', cleared: '已清空聊天。', timeout: '工具超时', noResponse: '（无响应）', stepLimit: '（已达工具调用次数上限）', keyWarn: '注意：密钥保存在此浏览器中，并随页面请求发送给 Google — 可在开发者工具中看到。请在 Google Cloud 中限制该密钥。请勿在公开网站的检查器中设置 geminiApiKey:。', remember: '在此浏览器中保存密钥', keySrc: '密钥来源', minimize: '最小化', restore: '还原' },
    'zh-TW': { title: 'AI 聊天', settings: '設定', clear: '清除聊天', apiKey: 'Gemini API 金鑰', apiKeyPh: 'AIza...（儲存於外掛儲存空間）', model: '模型', save: '儲存', saved: '已儲存', send: '傳送', inputPh: '詢問地圖相關...', welcome: '可以請我飛到某地、搜尋地點或切換圖層。', noKey: '未設定 API 金鑰 — 請在齒輪設定中新增。', noKeySet: '未設金鑰', keySet: '金鑰已設', tool: '工具', err: '錯誤', cleared: '已清除聊天。', timeout: '工具逾時', noResponse: '（無回應）', stepLimit: '（已達工具呼叫次數上限）', keyWarn: '注意：金鑰儲存在此瀏覽器中，並隨頁面請求傳送給 Google — 可在開發者工具中看到。請在 Google Cloud 限制該金鑰。請勿在公開網站的檢查器中設定 geminiApiKey:。', remember: '在此瀏覽器中儲存金鑰', keySrc: '金鑰來源', minimize: '最小化', restore: '還原' },
    ko: { title: 'AI 채팅', settings: '설정', clear: '채팅 지우기', apiKey: 'Gemini API 키', apiKeyPh: 'AIza...（플러그인 저장소에 저장）', model: '모델', save: '저장', saved: '저장됨', send: '전송', inputPh: '지도에 대해 물어보기...', welcome: '장소로 이동, 장소 검색, 레이어 전환 등을 요청하세요.', noKey: 'API 키 없음 — 톱니바퀴 설정에서 추가하세요.', noKeySet: '키 없음', keySet: '키 설정됨', tool: '도구', err: '오류', cleared: '채팅을 지웠습니다.', timeout: '도구 시간 초과', noResponse: '(응답 없음)', stepLimit: '(도구 호출 한도에 도달했습니다)', keyWarn: '참고: 키는 이 브라우저에 저장되고 페이지 요청으로 Google에 전송됩니다 — 개발자 도구에서 볼 수 있습니다. Google Cloud에서 키를 제한하세요. 공개 사이트에서는 인스펙터에 geminiApiKey: 를 설정하지 마세요.', remember: '이 브라우저에 키 저장', keySrc: '키 출처', minimize: '최소화', restore: '복원' },
    es: { title: 'Chat IA', settings: 'Ajustes', clear: 'Limpiar chat', apiKey: 'Clave API de Gemini', apiKeyPh: 'AIza... (guardada en el plugin)', model: 'Modelo', save: 'Guardar', saved: 'Guardado', send: 'Enviar', inputPh: 'Pregunta sobre el mapa...', welcome: 'Pídeme volar a un lugar, buscar sitios o cambiar capas.', noKey: 'Sin clave API — añádela en ajustes (engranaje).', noKeySet: 'sin clave', keySet: 'clave lista', tool: 'herramienta', err: 'Error', cleared: 'Chat limpiado.', timeout: 'Herramienta agotó el tiempo', noResponse: '(sin respuesta)', stepLimit: '(límite de pasos de herramientas alcanzado)', keyWarn: 'Nota: la clave se guarda en este navegador y se envía a Google en las solicitudes de la página — puede verse en devtools. Restríngela en Google Cloud. No definas geminiApiKey: en el inspector en sitios públicos.', remember: 'Guardar clave en este navegador', keySrc: 'Origen de la clave', minimize: 'Minimizar', restore: 'Restaurar' },
    fr: { title: 'Chat IA', settings: 'Paramètres', clear: 'Effacer le chat', apiKey: 'Clé API Gemini', apiKeyPh: 'AIza... (stockée dans le plugin)', model: 'Modèle', save: 'Enregistrer', saved: 'Enregistré', send: 'Envoyer', inputPh: 'Posez une question sur la carte...', welcome: 'Demandez-moi de voler quelque part, chercher un lieu ou gérer les couches.', noKey: 'Pas de clé API — ajoutez-la dans les paramètres (engrenage).', noKeySet: 'clé absente', keySet: 'clé définie', tool: 'outil', err: 'Erreur', cleared: 'Chat effacé.', timeout: 'Outil expiré', noResponse: '(pas de réponse)', stepLimit: '(limite d’étapes d’outils atteinte)', keyWarn: 'Note : la clé est stockée dans ce navigateur et envoyée à Google avec les requêtes de la page — visible dans les devtools. Restreignez-la dans Google Cloud. Ne définissez pas geminiApiKey: dans l’inspecteur sur les sites publics.', remember: 'Enregistrer la clé dans ce navigateur', keySrc: 'Source de la clé', minimize: 'Réduire', restore: 'Restaurer' },
    de: { title: 'KI-Chat', settings: 'Einstellungen', clear: 'Chat löschen', apiKey: 'Gemini API-Schlüssel', apiKeyPh: 'AIza... (im Plugin gespeichert)', model: 'Modell', save: 'Speichern', saved: 'Gespeichert', send: 'Senden', inputPh: 'Frage zur Karte stellen...', welcome: 'Lass mich irgendwo hinfliegen, Orte suchen oder Layer umschalten.', noKey: 'Kein API-Schlüssel — in den Einstellungen (Zahnrad) hinzufügen.', noKeySet: 'kein Schlüssel', keySet: 'Schlüssel gesetzt', tool: 'Werkzeug', err: 'Fehler', cleared: 'Chat gelöscht.', timeout: 'Werkzeug-Timeout', noResponse: '(keine Antwort)', stepLimit: '(Tool-Schrittlimit erreicht)', keyWarn: 'Hinweis: Der Schlüssel wird in diesem Browser gespeichert und mit Seitenanfragen an Google gesendet — in den DevTools sichtbar. Schränken Sie ihn in Google Cloud ein. Setzen Sie geminiApiKey: auf öffentlichen Seiten nicht im Inspector.', remember: 'Schlüssel in diesem Browser speichern', keySrc: 'Schlüsselquelle', minimize: 'Minimieren', restore: 'Wiederherstellen' },
    it: { title: 'Chat IA', settings: 'Impostazioni', clear: 'Cancella chat', apiKey: 'Chiave API Gemini', apiKeyPh: 'AIza... (salvata nel plugin)', model: 'Modello', save: 'Salva', saved: 'Salvato', send: 'Invia', inputPh: 'Chiedi sulla mappa...', welcome: 'Chiedimi di volare da qualche parte, cercare luoghi o cambiare layer.', noKey: 'Nessuna chiave API — aggiungila nelle impostazioni (ingranaggio).', noKeySet: 'chiave assente', keySet: 'chiave impostata', tool: 'strumento', err: 'Errore', cleared: 'Chat cancellata.', timeout: 'Strumento scaduto', noResponse: '(nessuna risposta)', stepLimit: '(limite di passaggi degli strumenti raggiunto)', keyWarn: 'Nota: la chiave è salvata in questo browser e inviata a Google con le richieste della pagina — visibile nei devtools. Limita la chiave in Google Cloud. Non impostare geminiApiKey: nell’inspector su siti pubblici.', remember: 'Salva chiave in questo browser', keySrc: 'Origine della chiave', minimize: 'Riduci', restore: 'Ripristina' },
    pt: { title: 'Chat IA', settings: 'Configurações', clear: 'Limpar chat', apiKey: 'Chave API Gemini', apiKeyPh: 'AIza... (guardada no plugin)', model: 'Modelo', save: 'Guardar', saved: 'Guardado', send: 'Enviar', inputPh: 'Pergunte sobre o mapa...', welcome: 'Peça-me para voar a um lugar, pesquisar locais ou alternar camadas.', noKey: 'Sem chave API — adicione nas configurações (engrenagem).', noKeySet: 'sem chave', keySet: 'chave definida', tool: 'ferramenta', err: 'Erro', cleared: 'Chat limpo.', timeout: 'Ferramenta expirou', noResponse: '(sem resposta)', stepLimit: '(limite de etapas de ferramentas atingido)', keyWarn: 'Nota: a chave é guardada neste navegador e enviada ao Google nos pedidos da página — visível nas devtools. Restrinja-a no Google Cloud. Não defina geminiApiKey: no inspetor em sites públicos.', remember: 'Guardar chave neste navegador', keySrc: 'Origem da chave', minimize: 'Minimizar', restore: 'Restaurar' },
    ru: { title: 'ИИ-чат', settings: 'Настройки', clear: 'Очистить чат', apiKey: 'API-ключ Gemini', apiKeyPh: 'AIza... (хранится в плагине)', model: 'Модель', save: 'Сохранить', saved: 'Сохранено', send: 'Отправить', inputPh: 'Спросите о карте...', welcome: 'Попросите меня долететь до места, найти объект или переключить слои.', noKey: 'Нет API-ключа — добавьте в настройках (шестерёнка).', noKeySet: 'ключа нет', keySet: 'ключ задан', tool: 'инструмент', err: 'Ошибка', cleared: 'Чат очищен.', timeout: 'Инструмент: таймаут', noResponse: '(нет ответа)', stepLimit: '(достигнут лимит шагов инструментов)', keyWarn: 'Примечание: ключ хранится в этом браузере и отправляется в Google с запросами страницы — виден в devtools. Ограничьте ключ в Google Cloud. Не задавайте geminiApiKey: в инспекторе на публичных сайтах.', remember: 'Сохранить ключ в этом браузере', keySrc: 'Источник ключа', minimize: 'Свернуть', restore: 'Восстановить' },
    nl: { title: 'AI-chat', settings: 'Instellingen', clear: 'Chat wissen', apiKey: 'Gemini API-sleutel', apiKeyPh: 'AIza... (opgeslagen in plugin)', model: 'Model', save: 'Opslaan', saved: 'Opgeslagen', send: 'Verzenden', inputPh: 'Vraag over de kaart...', welcome: 'Vraag me ergens heen te vliegen, plaatsen te zoeken of lagen te wisselen.', noKey: 'Geen API-sleutel — voeg toe via instellingen (tandwiel).', noKeySet: 'geen sleutel', keySet: 'sleutel gezet', tool: 'hulpmiddel', err: 'Fout', cleared: 'Chat gewist.', timeout: 'Hulpmiddel time-out', noResponse: '(geen antwoord)', stepLimit: '(limiet voor toolstappen bereikt)', keyWarn: 'Let op: de sleutel wordt in deze browser opgeslagen en met paginaverzoeken naar Google gestuurd — zichtbaar in devtools. Beperk de sleutel in Google Cloud. Stel geminiApiKey: niet in de inspector in op openbare sites.', remember: 'Sleutel opslaan in deze browser', keySrc: 'Sleutelbron', minimize: 'Minimaliseren', restore: 'Herstellen' },
    pl: { title: 'Czat AI', settings: 'Ustawienia', clear: 'Wyczyść czat', apiKey: 'Klucz API Gemini', apiKeyPh: 'AIza... (zapisany we wtyczce)', model: 'Model', save: 'Zapisz', saved: 'Zapisano', send: 'Wyślij', inputPh: 'Zapytaj o mapę...', welcome: 'Poproś o przelot w miejsce, wyszukanie lokalizacji lub przełączenie warstw.', noKey: 'Brak klucza API — dodaj w ustawieniach (zębatka).', noKeySet: 'brak klucza', keySet: 'klucz ustawiony', tool: 'narzędzie', err: 'Błąd', cleared: 'Czat wyczyszczony.', timeout: 'Przekroczono czas narzędzia', noResponse: '(brak odpowiedzi)', stepLimit: '(osiągnięto limit kroków narzędzi)', keyWarn: 'Uwaga: klucz jest zapisywany w tej przeglądarce i wysyłany do Google z żądaniami strony — widać go w devtools. Ogranicz klucz w Google Cloud. Nie ustawiaj geminiApiKey: w inspektorze na stronach publicznych.', remember: 'Zapisz klucz w tej przeglądarce', keySrc: 'Źródło klucza', minimize: 'Minimalizuj', restore: 'Przywróć' },
    uk: { title: 'AI-чат', settings: 'Налаштування', clear: 'Очистити чат', apiKey: 'API-ключ Gemini', apiKeyPh: 'AIza... (зберігається у плагіні)', model: 'Модель', save: 'Зберегти', saved: 'Збережено', send: 'Надіслати', inputPh: 'Запитайте про карту...', welcome: 'Попросіть мене полетіти кудись, знайти місце або перемкнути шари.', noKey: 'Немає API-ключа — додайте в налаштуваннях (шестерня).', noKeySet: 'ключа немає', keySet: 'ключ задано', tool: 'інструмент', err: 'Помилка', cleared: 'Чат очищено.', timeout: 'Інструмент: тайм-аут', noResponse: '(немає відповіді)', stepLimit: '(досягнуто ліміту кроків інструментів)', keyWarn: 'Примітка: ключ зберігається в цьому браузері й надсилається до Google із запитами сторінки — видно в devtools. Обмежте ключ у Google Cloud. Не задавайте geminiApiKey: в інспекторі на публічних сайтах.', remember: 'Зберегти ключ у цьому браузері', keySrc: 'Джерело ключа', minimize: 'Згорнути', restore: 'Відновити' },
    tr: { title: 'AI Sohbet', settings: 'Ayarlar', clear: 'Sohbeti temizle', apiKey: 'Gemini API anahtarı', apiKeyPh: 'AIza... (eklenti deposunda saklanır)', model: 'Model', save: 'Kaydet', saved: 'Kaydedildi', send: 'Gönder', inputPh: 'Harita hakkında sor...', welcome: 'Bir yere uçmamı, yer aramamı veya katmanları değiştirmemi isteyin.', noKey: 'API anahtarı yok — ayarlardan (dişli) ekleyin.', noKeySet: 'anahtar yok', keySet: 'anahtar var', tool: 'araç', err: 'Hata', cleared: 'Sohbet temizlendi.', timeout: 'Araç zaman aşımı', noResponse: '(yanıt yok)', stepLimit: '(araç adım sınırına ulaşıldı)', keyWarn: 'Not: anahtar bu tarayıcıda saklanır ve sayfa istekleriyle Google’a gönderilir — geliştirici araçlarında görülebilir. Google Cloud içinde anahtarı kısıtlayın. Herkese açık sitelerde denetçide geminiApiKey: ayarlamayın.', remember: 'Anahtarı bu tarayıcıya kaydet', keySrc: 'Anahtar kaynağı', minimize: 'Küçült', restore: 'Geri yükle' },
    ar: { title: 'دردشة الذكاء الاصطناعي', settings: 'الإعدادات', clear: 'مسح الدردشة', apiKey: 'مفتاح Gemini API', apiKeyPh: 'AIza... (يُحفظ في الإضافة)', model: 'النموذج', save: 'حفظ', saved: 'تم الحفظ', send: 'إرسال', inputPh: 'اسأل عن الخريطة...', welcome: 'اطلب مني الطيران إلى مكان أو البحث عن مواقع أو تبديل الطبقات.', noKey: 'لا يوجد مفتاح API — أضفه من الإعدادات (الترس).', noKeySet: 'لا مفتاح', keySet: 'المفتاح مضبوط', tool: 'أداة', err: 'خطأ', cleared: 'تم مسح الدردشة.', timeout: 'انتهت مهلة الأداة', noResponse: '(لا رد)', stepLimit: '(تم بلوغ حد خطوات الأداة)', keyWarn: 'ملاحظة: يُحفظ المفتاح في هذا المتصفح ويُرسل إلى Google مع طلبات الصفحة — يظهر في أدوات المطوّر. قيّد المفتاح في Google Cloud. لا تضبط geminiApiKey: في المفتش على المواقع العامة.', remember: 'حفظ المفتاح في هذا المتصفح', keySrc: 'مصدر المفتاح', minimize: 'تصغير', restore: 'استعادة' },
    hi: { title: 'AI चैट', settings: 'सेटिंग्स', clear: 'चैट साफ़ करें', apiKey: 'Gemini API कुंजी', apiKeyPh: 'AIza... (प्लगइन स्टोरेज में सहेजी जाती है)', model: 'मॉडल', save: 'सहेजें', saved: 'सहेजा गया', send: 'भेजें', inputPh: 'नक्शे के बारे में पूछें...', welcome: 'कहीं उड़ने, स्थान खोजने या लेयर बदलने के लिए कहें।', noKey: 'API कुंजी नहीं — सेटिंग्स (गियर) में जोड़ें।', noKeySet: 'कुंजी नहीं', keySet: 'कुंजी सेट', tool: 'उपकरण', err: 'त्रुटि', cleared: 'चैट साफ़ की गई।', timeout: 'उपकरण समय समाप्त', noResponse: '(कोई प्रतिक्रिया नहीं)', stepLimit: '(उपकरण चरण सीमा पहुंची)', keyWarn: 'नोट: कुंजी इस ब्राउज़र में सहेजी जाती है और पेज अनुरोधों के साथ Google को भेजी जाती है — devtools में दिख सकती है। Google Cloud में कुंजी को प्रतिबंधित करें। सार्वजनिक साइटों पर इंस्पेक्टर में geminiApiKey: सेट न करें।', remember: 'इस ब्राउज़र में कुंजी सहेजें', keySrc: 'कुंजी स्रोत', minimize: 'छोटा करें', restore: 'पुनर्स्थापित' },
    id: { title: 'Obrolan AI', settings: 'Pengaturan', clear: 'Bersihkan chat', apiKey: 'Kunci API Gemini', apiKeyPh: 'AIza... (disimpan di plugin)', model: 'Model', save: 'Simpan', saved: 'Tersimpan', send: 'Kirim', inputPh: 'Tanya tentang peta...', welcome: 'Minta saya terbang ke suatu tempat, mencari lokasi, atau mengganti layer.', noKey: 'Belum ada kunci API — tambahkan di pengaturan (roda gigi).', noKeySet: 'tanpa kunci', keySet: 'kunci terpasang', tool: 'alat', err: 'Kesalahan', cleared: 'Chat dibersihkan.', timeout: 'Alat kedaluwarsa', noResponse: '(tidak ada respons)', stepLimit: '(batas langkah alat tercapai)', keyWarn: 'Catatan: kunci disimpan di browser ini dan dikirim ke Google melalui permintaan halaman — terlihat di devtools. Batasi kunci di Google Cloud. Jangan setel geminiApiKey: di inspector pada situs publik.', remember: 'Simpan kunci di browser ini', keySrc: 'Sumber kunci', minimize: 'Minimalkan', restore: 'Pulihkan' },
    th: { title: 'แชท AI', settings: 'การตั้งค่า', clear: 'ล้างแชท', apiKey: 'คีย์ API ของ Gemini', apiKeyPh: 'AIza... (จัดเก็บในปลั๊กอิน)', model: 'โมเดล', save: 'บันทึก', saved: 'บันทึกแล้ว', send: 'ส่ง', inputPh: 'ถามเกี่ยวกับแผนที่...', welcome: 'ขอให้ผมบินไปที่ใดสักแห่ง ค้นหาสถานที่ หรือสลับเลเยอร์ได้', noKey: 'ไม่มีคีย์ API — เพิ่มในการตั้งค่า (ฟันเฟือง)', noKeySet: 'ไม่มีคีย์', keySet: 'ตั้งคีย์แล้ว', tool: 'เครื่องมือ', err: 'ข้อผิดพลาด', cleared: 'ล้างแชทแล้ว', timeout: 'เครื่องมือหมดเวลา', noResponse: '(ไม่มีการตอบกลับ)', stepLimit: '(ถึงขีดจำกัดขั้นตอนเครื่องมือแล้ว)', keyWarn: 'หมายเหตุ: คีย์จะถูกเก็บในเบราว์เซอร์นี้และส่งไปยัง Google พร้อมคำขอของหน้า — มองเห็นได้ใน devtools โปรดจำกัดคีย์ใน Google Cloud อย่าตั้ง geminiApiKey: ใน inspector บนเว็บไซต์สาธารณะ', remember: 'บันทึกคีย์ในเบราว์เซอร์นี้', keySrc: 'แหล่งที่มาของคีย์', minimize: 'ย่อ', restore: 'คืนค่า' },
    vi: { title: 'Trò chuyện AI', settings: 'Cài đặt', clear: 'Xóa trò chuyện', apiKey: 'Khóa API Gemini', apiKeyPh: 'AIza... (lưu trong plugin)', model: 'Mô hình', save: 'Lưu', saved: 'Đã lưu', send: 'Gửi', inputPh: 'Hỏi về bản đồ...', welcome: 'Hãy yêu cầu tôi bay đến một nơi, tìm địa điểm hoặc bật/tắt lớp.', noKey: 'Chưa có khóa API — thêm trong cài đặt (bánh răng).', noKeySet: 'chưa có khóa', keySet: 'đã có khóa', tool: 'công cụ', err: 'Lỗi', cleared: 'Đã xóa trò chuyện.', timeout: 'Công cụ hết thời gian', noResponse: '(không có phản hồi)', stepLimit: '(đã đạt giới hạn bước công cụ)', keyWarn: 'Lưu ý: khóa được lưu trong trình duyệt này và gửi tới Google cùng yêu cầu trang — có thể xem trong devtools. Hãy giới hạn khóa trong Google Cloud. Không đặt geminiApiKey: trong inspector trên trang công khai.', remember: 'Lưu khóa trong trình duyệt này', keySrc: 'Nguồn khóa', minimize: 'Thu nhỏ', restore: 'Khôi phục' },
};
const html = `
<style>
  html, body { margin:0; padding:0; width:320px; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif; }
  .ai-wrap { background:rgba(255,255,255,0.92); border-radius:8px; box-shadow:0 2px 10px rgba(0,0,0,0.2); backdrop-filter:blur(4px); width:312px; display:flex; flex-direction:column; overflow:hidden; box-sizing:border-box; }
  .ai-head { display:flex; align-items:center; gap:6px; padding:6px 8px; border-bottom:1px solid #e3e3e3; background:#f7f9fc; }
  .ai-title { font-size:0.85em; font-weight:600; color:#333; flex:1; }
  .ai-head button { border:1px solid #ccc; background:#fff; border-radius:4px; width:26px; height:24px; font-size:0.85em; cursor:pointer; line-height:1; padding:0; }
  .ai-head button:hover { background:#eef2fa; }
  .ai-msgs { height:300px; overflow-y:auto; padding:8px; display:flex; flex-direction:column; gap:6px; background:#fff; }
  .ai-msg { max-width:92%; padding:6px 9px; border-radius:10px; font-size:0.82em; line-height:1.45; white-space:pre-wrap; overflow-wrap:break-word; }
  .ai-msg.user { align-self:flex-end; background:#dcf0ff; color:#123; }
  .ai-msg.bot { align-self:flex-start; background:#f1f1f4; color:#222; }
  .ai-msg.sys { align-self:center; background:transparent; color:#888; font-size:0.75em; padding:2px; }
  .ai-msg.tool { align-self:flex-start; background:#eef8ee; color:#475; font-size:0.72em; padding:3px 8px; border:1px solid #d9ead9; font-family:monospace; }
  .ai-msg img { max-width:100%; border-radius:6px; display:block; margin-top:4px; }
  .ai-form { display:flex; gap:6px; padding:8px; border-top:1px solid #e3e3e3; background:#fafafa; }
  .ai-form input { flex:1; border:1px solid #ccc; border-radius:6px; padding:7px 9px; font-size:0.85em; min-width:0; }
  .ai-form button { border:1px solid #3b7bd4; background:#3b7bd4; color:#fff; border-radius:6px; padding:0 14px; font-size:0.85em; cursor:pointer; }
  .ai-form button:disabled { opacity:0.5; cursor:default; }
  .ai-settings { display:none; flex-direction:column; gap:6px; padding:8px; border-top:1px solid #e3e3e3; background:#fdfdf8; font-size:0.78em; }
  .ai-settings.open { display:flex; }
  .ai-settings label { color:#444; font-weight:600; }
  .ai-settings input { border:1px solid #ccc; border-radius:4px; padding:5px 7px; font-size:1em; width:100%; box-sizing:border-box; }
  .ai-settings .row { display:flex; gap:6px; align-items:center; }
  .ai-settings button { border:1px solid #3b7bd4; background:#3b7bd4; color:#fff; border-radius:4px; padding:5px 12px; cursor:pointer; font-size:1em; }
  .ai-key-status { color:#a64; font-size:0.9em; }
  .ai-key-status.ok { color:#4a4; }
  .ai-key-src { color:#777; font-size:0.85em; }
  .ai-key-warn { color:#a33; font-size:0.82em; line-height:1.35; }
  .ai-wrap.minimized .ai-msgs,
  .ai-wrap.minimized .ai-form,
  .ai-wrap.minimized .ai-settings { display:none !important; }
</style>
<div class="ai-wrap">
  <div class="ai-head">
    <div class="ai-title" data-i18n="title">AI Chat</div>
    <button id="ai-settings-btn" data-i18n-title="settings" title="Settings">&#9881;</button>
    <button id="ai-clear-btn" data-i18n-title="clear" title="Clear">&#128465;</button>
    <button id="ai-min-btn" data-i18n-title="minimize" title="Minimize">&mdash;</button>
  </div>
  <div id="ai-msgs" class="ai-msgs"></div>
  <div id="ai-settings" class="ai-settings">
    <label data-i18n="provider">Provider</label>
    <select id="ai-provider">
      <option value="gemini">Gemini</option>
      <option value="copilot">GitHub Copilot (bridge hub)</option>
      <option value="openai">OpenAI-compatible</option>
      <option value="anthropic">Anthropic</option>
      <option value="azure">Azure OpenAI</option>
      <option value="agent">External agent (bridge)</option>
    </select>
    <div class="pv-field" data-pv="openai azure anthropic agent copilot"><label data-i18n="endpoint">Endpoint</label>
    <input id="ai-endpoint" type="text" autocomplete="off" placeholder="https://..."></div>
    <div class="pv-field" data-pv="azure"><label data-i18n="apiVer">API version</label>
    <input id="ai-apiver" type="text" autocomplete="off" placeholder="2024-10-21"></div>
    <div class="pv-field" data-pv="gemini openai anthropic azure"><div class="row"><label data-i18n="apiKey" style="flex:1;">Gemini API key</label><span id="ai-key-status" class="ai-key-status"></span></div>
    <input id="ai-key" type="password" autocomplete="off" data-i18n-ph="apiKeyPh" placeholder="AIza..."></div>
    <div id="ai-key-src" class="ai-key-src"></div>
    <div class="pv-field" data-pv="gemini openai anthropic azure copilot"><label data-i18n="model">Model</label>
    <input id="ai-model" type="text" placeholder="gemini-3.1-flash-lite" list="ai-model-list"><datalist id="ai-model-list"></datalist>
    <div id="ai-hub-status" class="ai-key-src" style="display:none;"></div></div>
    <div class="pv-field" data-pv="agent"><label data-i18n="agentModel">Agent note</label>
    <input id="ai-agentmodel" type="text" autocomplete="off" placeholder="(optional)"></div>
    <div class="row"><label style="font-weight:400;display:flex;align-items:center;gap:6px;flex:1;cursor:pointer;"><input id="ai-remember" type="checkbox" style="width:auto;margin:0;"><span data-i18n="remember">Save key on this browser</span></label></div>
    <div class="row"><button id="ai-save" data-i18n="save">Save</button><span id="ai-save-msg" style="color:#4a4;"></span></div>
    <div class="ai-key-warn" data-i18n="keyWarn">Note: the key is stored in this browser and sent to Google in page requests — it can be seen in devtools. Restrict it in Google Cloud. Do not set geminiApiKey: in the inspector on public sites.</div>
  </div>
  <form id="ai-form" class="ai-form">
    <input id="ai-input" data-i18n-ph="inputPh" placeholder="Ask about the map..." autocomplete="off">
    <button id="ai-send" type="button" data-i18n="send">Send</button>
  </form>
</div>
<script>
(function(){
  // --- i18n (English base; missing keys fall back to en) ---
  var GEO_I18N = {
    en: { title:'AI Chat', settings:'Settings', clear:'Clear chat', apiKey:'Gemini API key', apiKeyPh:'AIza... (stored in plugin storage)', model:'Model', save:'Save', saved:'Saved', send:'Send', inputPh:'Ask about the map...', welcome:'Ask me to fly somewhere, search places, or toggle layers.', noKey:'No API key — open settings (gear) to add one.', noKeySet:'key not set', keySet:'key set', tool:'tool', err:'Error', cleared:'Chat cleared.', timeout:'Tool timed out', noResponse:'(no response)', stepLimit:'(tool step limit reached)', keyWarn:'Note: the key is stored in this browser and sent to Google in page requests — it can be seen in devtools. Restrict it in Google Cloud. Do not set geminiApiKey: in the inspector on public sites.', remember:'Save key on this browser', keySrc:'Key source' , minimize:"Minimize", restore:"Restore", provider:'Provider', endpoint:'Endpoint URL', apiVer:'API version', agentModel:'Agent label (optional)' }
  };
  var GEO_SUPPORTED = ['en','ja','zh-CN','zh-TW','ko','es','fr','de','it','pt','ru','nl','pl','uk','tr','ar','hi','id','th','vi'];
  var GEO_LANG = 'en';
  function resolveLang() {
    try {
      var conf = String(window._GEO_LANG_CONF || 'auto').toLowerCase().trim();
      var cand = (conf && conf !== 'auto') ? conf : String((navigator.languages && navigator.languages[0]) || navigator.language || 'en').toLowerCase();
      if (cand.indexOf('zh') === 0) {
        return (cand.indexOf('tw') > -1 || cand.indexOf('hk') > -1 || cand.indexOf('mo') > -1 || cand.indexOf('hant') > -1) ? 'zh-TW' : 'zh-CN';
      }
      var i;
      for (i = 0; i < GEO_SUPPORTED.length; i++) { if (GEO_SUPPORTED[i].toLowerCase() === cand) return GEO_SUPPORTED[i]; }
      var base = cand.split('-')[0];
      for (i = 0; i < GEO_SUPPORTED.length; i++) { if (GEO_SUPPORTED[i].toLowerCase().split('-')[0] === base) return GEO_SUPPORTED[i]; }
    } catch (e) {}
    return 'en';
  }
  GEO_LANG = resolveLang();
  function t(key) {
    return (GEO_I18N[GEO_LANG] && GEO_I18N[GEO_LANG][key]) || (GEO_I18N.en && GEO_I18N.en[key]) || key;
  }
  function applyI18n() {
    try {
      try { document.documentElement.lang = GEO_LANG; } catch (e) {}
      var apply = function(sel, fn) {
        try {
          var nodes = document.querySelectorAll(sel);
          for (var i = 0; i < nodes.length; i++) { try { fn(nodes[i]); } catch (e) {} }
        } catch (e) {}
      };
      apply('[data-i18n]', function(el) { el.textContent = t(el.getAttribute('data-i18n')); });
      apply('[data-i18n-title]', function(el) { el.setAttribute('title', t(el.getAttribute('data-i18n-title'))); });
      apply('[data-i18n-ph]', function(el) { el.setAttribute('placeholder', t(el.getAttribute('data-i18n-ph'))); });
    } catch (e) {}
  }
  applyI18n();

  // ---------- tool declarations for Gemini function calling ----------
  var TOOL_DECLS = [{ functionDeclarations: [
    { name:'getCamera', description:'Get the current camera position/orientation', parameters:{ type:'OBJECT', properties:{} } },
    { name:'flyTo', description:'Fly the camera to a location. lat/lng in degrees, height in meters, heading/pitch in degrees (-90 = straight down). Omit height/heading/pitch to keep current values.', parameters:{ type:'OBJECT', properties:{ lat:{type:'NUMBER'}, lng:{type:'NUMBER'}, height:{type:'NUMBER'}, heading:{type:'NUMBER'}, pitch:{type:'NUMBER'}, duration:{type:'NUMBER', description:'flight seconds'} }, required:['lat','lng'] } },
    { name:'searchLocation', description:'Search for a place or address by keyword (Japan GSI geocoding by default; provider "yahoo" uses Yahoo Local Search, "auto" tries Yahoo then GSI). Returns candidate names with lat/lng — call flyTo afterwards to move.', parameters:{ type:'OBJECT', properties:{ query:{type:'STRING'}, limit:{type:'NUMBER'}, provider:{type:'STRING', description:'gsi (default) | yahoo | auto'} }, required:['query'] } },
    { name:'searchPlaces', description:'Search places/POIs worldwide via Google (Geocoding + Places Text Search, merged). Requires googleMapsApiKey in the plugin inspector. Returns names, addresses and lat/lng — call flyTo afterwards to move.', parameters:{ type:'OBJECT', properties:{ query:{type:'STRING'}, limit:{type:'NUMBER'} }, required:['query'] } },
    { name:'vectorSearch', description:'Search loaded vector layer attributes by text (optionally filtered to one layer/attribute). Returns matching attribute/value hits with lat/lng — call flyTo or showFeatureAttributes afterwards.', parameters:{ type:'OBJECT', properties:{ query:{type:'STRING'}, layer:{type:'STRING'}, attribute:{type:'STRING'}, limit:{type:'NUMBER'} }, required:['query'] } },
    { name:'listLayers', description:'List map layers (id, title, type, visible)', parameters:{ type:'OBJECT', properties:{} } },
    { name:'setLayerVisible', description:'Show or hide a layer by title or id', parameters:{ type:'OBJECT', properties:{ layer:{type:'STRING'}, visible:{type:'BOOLEAN'} }, required:['layer','visible'] } },
    { name:'focusLayer', description:'Fly the camera to a layer extent', parameters:{ type:'OBJECT', properties:{ layer:{type:'STRING'} }, required:['layer'] } },
    { name:'addGeoJsonLayer', description:'Add a GeoJSON layer from a URL', parameters:{ type:'OBJECT', properties:{ title:{type:'STRING'}, url:{type:'STRING'} }, required:['url'] } },
    { name:'addTileLayer', description:'Add an XYZ raster tile layer; url contains {z}/{x}/{y}', parameters:{ type:'OBJECT', properties:{ title:{type:'STRING'}, url:{type:'STRING'}, minLevel:{type:'NUMBER'}, maxLevel:{type:'NUMBER'} }, required:['url'] } },
    { name:'add3dTilesLayer', description:'Add an OGC 3D Tiles layer (tileset.json URL)', parameters:{ type:'OBJECT', properties:{ title:{type:'STRING'}, url:{type:'STRING'} }, required:['url'] } },
    { name:'removeLayer', description:'Remove a layer previously added by the AI', parameters:{ type:'OBJECT', properties:{ layer:{type:'STRING'} }, required:['layer'] } },
    { name:'listCameraPresets', description:'List named camera presets defined in the plugin inspector', parameters:{ type:'OBJECT', properties:{} } },
    { name:'flyToPreset', description:'Fly to a named camera preset. Replies after the flight completes; pass wait:false to reply immediately after issuing.', parameters:{ type:'OBJECT', properties:{ name:{type:'STRING'}, wait:{type:'BOOLEAN'} }, required:['name'] } },
    { name:'listBasemaps', description:'List available basemaps', parameters:{ type:'OBJECT', properties:{} } },
    { name:'setBasemap', description:'Switch the basemap by name; pass empty/none to clear', parameters:{ type:'OBJECT', properties:{ name:{type:'STRING'} }, required:['name'] } },
    { name:'listFlyPaths', description:'List flight routes (fly paths) defined in the inspector or drawn', parameters:{ type:'OBJECT', properties:{} } },
    { name:'playFlyPath', description:'Start an automatic camera flight along a named route', parameters:{ type:'OBJECT', properties:{ name:{type:'STRING'} }, required:['name'] } },
    { name:'stopFly', description:'Stop the current route flight', parameters:{ type:'OBJECT', properties:{} } },
    { name:'setTerrain', description:'Enable or disable 3D terrain', parameters:{ type:'OBJECT', properties:{ enabled:{type:'BOOLEAN'} }, required:['enabled'] } },
    { name:'setShadow', description:'Enable or disable shadows', parameters:{ type:'OBJECT', properties:{ enabled:{type:'BOOLEAN'} }, required:['enabled'] } },
    { name:'openStreetView', description:'Open Google Street View at the map center in a new tab', parameters:{ type:'OBJECT', properties:{} } },
    { name:'flyToFeature', description:'Fly to a vector feature whose attribute matches a value (optionally within a named layer). Replies after the flight; pass wait:false for an immediate ack.', parameters:{ type:'OBJECT', properties:{ attribute:{type:'STRING'}, value:{type:'STRING'}, layer:{type:'STRING'}, wait:{type:'BOOLEAN'} }, required:['attribute','value'] } },
    { name:'captureView', description:'Capture a screenshot of the current map view', parameters:{ type:'OBJECT', properties:{} } },
    { name:'getShareUrl', description:'Get a permalink query string (?lat=...&lng=...) for the current view', parameters:{ type:'OBJECT', properties:{} } },
    { name:'addFlatGeobufLayer', description:'Add a FlatGeobuf (.fgb) vector layer by URL — decoded to GeoJSON in the browser and styled like a geojson layer.', parameters:{ type:'OBJECT', properties:{ url:{type:'STRING'}, title:{type:'STRING'}, visible:{type:'BOOLEAN'}, limit:{type:'NUMBER', description:'max features (default 200000)'} }, required:['url'] } },
    { name:'addParquetLayer', description:'Add a GeoParquet (.parquet) vector layer by URL — decoded to GeoJSON in the browser and styled like a geojson layer.', parameters:{ type:'OBJECT', properties:{ url:{type:'STRING'}, title:{type:'STRING'}, visible:{type:'BOOLEAN'}, limit:{type:'NUMBER', description:'max features (default 200000)'} }, required:['url'] } },
    { name:'addDuckDbLayer', description:'Add a query layer backed by DuckDB-Wasm — SQL pushdown (where/limit/columns) and covering-bbox row-group skipping enable partial loading of large remote files (parquet/csv/json). bbox=auto re-queries on camera move.', parameters:{ type:'OBJECT', properties:{ url:{type:'STRING'}, title:{type:'STRING'}, visible:{type:'BOOLEAN'}, where:{type:'STRING', description:'SQL WHERE predicate'}, limit:{type:'NUMBER'}, format:{type:'STRING', description:'parquet|csv|tsv|json (default: by extension)'}, geom:{type:'STRING'}, lon:{type:'STRING'}, lat:{type:'STRING'}, columns:{type:'STRING', description:'comma-separated column names to read'}, bbox:{type:'BOOLEAN', description:'viewport-linked partial loading (default true)'} }, required:['url'] } },
    { name:'buildShareUrl', description:'Build a permalink query string for an arbitrary viewpoint (e.g. to embed section links in a report). lat/lng required; height meters, heading/pitch degrees optional.', parameters:{ type:'OBJECT', properties:{ lat:{type:'NUMBER'}, lng:{type:'NUMBER'}, height:{type:'NUMBER'}, heading:{type:'NUMBER'}, pitch:{type:'NUMBER'} }, required:['lat','lng'] } },
    { name:'showReport', description:'Show a Markdown or HTML report in a modal overlay (with download/copy actions). Use after gathering data to present a document to the user.', parameters:{ type:'OBJECT', properties:{ title:{type:'STRING'}, markdown:{type:'STRING'}, html:{type:'STRING'} } } },
    { name:'setCamera', description:'Instantly place the camera (no animation). lat/lng in degrees, height in meters, heading/pitch/roll in degrees.', parameters:{ type:'OBJECT', properties:{ lat:{type:'NUMBER'}, lng:{type:'NUMBER'}, height:{type:'NUMBER'}, heading:{type:'NUMBER'}, pitch:{type:'NUMBER'}, roll:{type:'NUMBER'} }, required:['lat','lng'] } },
    { name:'lookAt', description:'Aim the camera at a target point. range = distance in meters, instant = no animation.', parameters:{ type:'OBJECT', properties:{ lat:{type:'NUMBER'}, lng:{type:'NUMBER'}, height:{type:'NUMBER'}, heading:{type:'NUMBER'}, pitch:{type:'NUMBER'}, range:{type:'NUMBER'}, duration:{type:'NUMBER'}, instant:{type:'BOOLEAN'} }, required:['lat','lng'] } },
    { name:'zoomIn', description:'Zoom in by a factor (default 2)', parameters:{ type:'OBJECT', properties:{ amount:{type:'NUMBER'} } } },
    { name:'zoomOut', description:'Zoom out by a factor (default 2)', parameters:{ type:'OBJECT', properties:{ amount:{type:'NUMBER'} } } },
    { name:'openUrl', description:'Open a URL in a new browser tab (e.g. Google Maps or Google Earth links). May be popup-blocked; the URL is returned so it can be shown as a link instead.', parameters:{ type:'OBJECT', properties:{ url:{type:'STRING'} }, required:['url'] } },
    { name:'flyToCurrentLocation', description:'Fly to the user\\'s current geolocation (browser permission required)', parameters:{ type:'OBJECT', properties:{} } },
    { name:'flyToUrl', description:'Parse a shared map URL or a "?lat=..&lng=.." query string and fly the camera there', parameters:{ type:'OBJECT', properties:{ url:{type:'STRING'} }, required:['url'] } },
    { name:'createFlyPath', description:'Create a named fly route from coordinates [[lng,lat,(height)],...]. Saved as a drawn route and playable via playFlyPath.', parameters:{ type:'OBJECT', properties:{ name:{type:'STRING'}, coordinates:{type:'ARRAY', items:{type:'ARRAY', items:{type:'NUMBER'}}}, speed:{type:'NUMBER'}, height:{type:'NUMBER'}, pitch:{type:'NUMBER'}, loop:{type:'BOOLEAN'}, view:{type:'STRING'} }, required:['name','coordinates'] } },
    { name:'deleteFlyPath', description:'Delete a drawn fly route by name (inspector-defined routes cannot be deleted)', parameters:{ type:'OBJECT', properties:{ name:{type:'STRING'} }, required:['name'] } },
    { name:'setFlySettings', description:'Change fly route playback settings. name targets a route (default: currently selected). speed km/h, height/agl meters above ground, pitch degrees (negative looks down), loop boolean, view "camera" (first person) or "center" (follow). Applies live to a running flight.', parameters:{ type:'OBJECT', properties:{ name:{type:'STRING'}, speed:{type:'NUMBER'}, height:{type:'NUMBER'}, agl:{type:'NUMBER'}, pitch:{type:'NUMBER'}, loop:{type:'BOOLEAN'}, view:{type:'STRING'} } } },
    { name:'showPanel', description:'Open a panel in the Layers widget. panel: layers|legend|search|attr|cams|display|info|fly|share|manage', parameters:{ type:'OBJECT', properties:{ panel:{type:'STRING'} }, required:['panel'] } },
    { name:'showInfo', description:'Load a URL into the Info tab iframe and open the tab. Without url, opens the current Info tab.', parameters:{ type:'OBJECT', properties:{ url:{type:'STRING'} } } },
    { name:'listLegends', description:'List legend images defined in the plugin inspector', parameters:{ type:'OBJECT', properties:{} } },
    { name:'showFeatureAttributes', description:'Display a vector feature\\'s attributes in the Attr panel and fly to it (fly:false = panel only, wait:false = reply immediately after issuing the flight)', parameters:{ type:'OBJECT', properties:{ attribute:{type:'STRING'}, value:{type:'STRING'}, layer:{type:'STRING'}, fly:{type:'BOOLEAN'}, wait:{type:'BOOLEAN'} }, required:['attribute','value'] } },
    { name:'getInspectorText', description:'Get the plugin inspector settings text (layers, cams, routes, basemaps, legends etc.)', parameters:{ type:'OBJECT', properties:{} } },
    { name:'applyInspectorText', description:'Replace the plugin inspector settings text and apply it. Read the current text with getInspectorText first, then modify only the needed lines.', parameters:{ type:'OBJECT', properties:{ text:{type:'STRING'} }, required:['text'] } },
    { name:'setDepthTest', description:'Enable or disable depth test against terrain', parameters:{ type:'OBJECT', properties:{ enabled:{type:'BOOLEAN'} }, required:['enabled'] } },
    { name:'setGeojsonDrape', description:'Set how GeoJSON layers drape: 3dtiles | terrain | both', parameters:{ type:'OBJECT', properties:{ classification:{type:'STRING'} }, required:['classification'] } },
    { name:'setBackground', description:'Set the globe/scene background color as #rgb, #rrggbb or #rrggbbaa', parameters:{ type:'OBJECT', properties:{ color:{type:'STRING'} }, required:['color'] } },
    { name:'aiChatSend', description:'Send a message to the AI chat panel itself and return its reply (drives the chat)', parameters:{ type:'OBJECT', properties:{ text:{type:'STRING'} }, required:['text'] } },
    { name:'aiChatStatus', description:'Get the AI chat panel state (provider/model/key/busy)', parameters:{ type:'OBJECT', properties:{} } },
    { name:'aiChatSet', description:'Configure the AI chat provider/endpoint/model/apiKey (persist:false to keep it session-only)', parameters:{ type:'OBJECT', properties:{ provider:{type:'STRING'}, endpoint:{type:'STRING'}, model:{type:'STRING'}, apiKey:{type:'STRING'}, apiVer:{type:'STRING'}, persist:{type:'BOOLEAN'} } } },
    { name:'runCode', description:'Run sandboxed JavaScript for multi-step tasks. An async "api" object is available with methods: flyTo, setCamera, lookAt, zoomIn, zoomOut, getCamera, listLayers, setLayerVisible, focusLayer, addGeoJsonLayer, addTileLayer, add3dTilesLayer, addFlatGeobufLayer, addParquetLayer, addDuckDbLayer, removeLayer, searchLocation, searchPlaces, vectorSearch, listCameraPresets, flyToPreset, listBasemaps, setBasemap, setTerrain, setShadow, setDepthTest, setGeojsonDrape, setBackground, captureView, flyToFeature, showFeatureAttributes, playFlyPath, stopFly, createFlyPath, deleteFlyPath, setFlySettings, listFlyPaths, openStreetView, openUrl, getShareUrl, buildShareUrl, showReport, flyToUrl, flyToCurrentLocation, showPanel, showInfo, listLegends, getInspectorText, applyInspectorText. Each takes one args object and returns a promise. fetch() is also available. Use return to produce a result.', parameters:{ type:'OBJECT', properties:{ code:{type:'STRING', description:'async function body; use await api.xxx(...)'} }, required:['code'] } }
  ] }];

  var API_METHODS = ['flyTo','getCamera','listLayers','setLayerVisible','focusLayer','addGeoJsonLayer','addTileLayer','add3dTilesLayer','removeLayer','listCameraPresets','flyToPreset','listBasemaps','setBasemap','setTerrain','setShadow','captureView','flyToFeature','playFlyPath','stopFly','openStreetView','getShareUrl','setCamera','lookAt','zoomIn','zoomOut','openUrl','createFlyPath','deleteFlyPath','setFlySettings','listFlyPaths','vectorSearch','searchPlaces','buildShareUrl','addFlatGeobufLayer','addParquetLayer','addDuckDbLayer','showPanel','showInfo','listLegends','showFeatureAttributes','getInspectorText','applyInspectorText','setDepthTest','setGeojsonDrape','setBackground'];

  var SYSTEM_INSTRUCTION = [
    'You are an AI assistant embedded inside a Re:Earth 3D GIS map viewer (geo_suite plugin).',
    'You control the map through tools. Units: lat/lng in degrees (WGS84), height in meters, heading/pitch in degrees (pitch -90 = straight down, 0 = horizon).',
    'To go to a named place, first call searchLocation to geocode, then flyTo the returned lat/lng.',
    'Layers and basemaps must be referenced by the names returned from listLayers/listBasemaps/listCameraPresets/listFlyPaths — call those first if unsure of exact names.',
    'For multi-step or data-processing tasks, prefer runCode.',
    'Keep answers concise and respond in the same language as the user. Never claim an action succeeded when a tool returned an error.'
  ].join(' ');

  // ---------- state ----------
  var msgsEl = document.getElementById('ai-msgs');
  var inputEl = document.getElementById('ai-input');
  var sendBtn = document.getElementById('ai-send');
  var form = document.getElementById('ai-form');
  var settingsPanel = document.getElementById('ai-settings');
  var keyInput = document.getElementById('ai-key');
  var modelInput = document.getElementById('ai-model');
  var rememberEl = document.getElementById('ai-remember');
  var keyStatus = document.getElementById('ai-key-status');
  var keySrcEl = document.getElementById('ai-key-src');
  var saveMsg = document.getElementById('ai-save-msg');
  var _chatReplyCb = null; // one-shot reply resolver for aiChatSend (bridge control)
  var providerSel = document.getElementById('ai-provider');
  var endpointInput = document.getElementById('ai-endpoint');
  var apiverInput = document.getElementById('ai-apiver');
  var agentModelInput = document.getElementById('ai-agentmodel');
  var _provider = 'gemini';
  function applyProviderFields() {
    var pv = providerSel ? providerSel.value : 'gemini';
    _provider = pv;
    document.querySelectorAll('.pv-field').forEach(function(el) {
      el.style.display = ((el.getAttribute('data-pv') || '').indexOf(pv) >= 0) ? '' : 'none';
    });
    if (pv === 'copilot') {
      if (endpointInput && !endpointInput.value.trim()) endpointInput.value = 'http://127.0.0.1:8511/agent';
      if (modelInput && /^gemini-/.test(modelInput.value)) modelInput.value = '';
    }
    try { updateKeyStatus(); } catch (e) {}
    try { refreshProviderModels(); } catch (e) {}
  }
  if (providerSel) providerSel.addEventListener('change', applyProviderFields);
  if (endpointInput) endpointInput.addEventListener('change', function() { try { refreshProviderModels(); } catch (e) {} });
  if (keyInput) keyInput.addEventListener('change', function() { try { refreshProviderModels(); } catch (e) {} });

  var _apiKey = '';
  var _model = 'gemini-3.1-flash-lite';
  var _keySource = 'none';
  var _history = [];
  var _reqSeq = 0;
  var _pendingTools = {};
  var _busy = false;
  var _userToggledMin = false;
  var _configReceived = false;

  function postToParent(m) {
    try { if (window.parent) window.parent.postMessage(m, '*'); } catch (e) {}
  }

  function addMsg(cls, text) {
    var d = document.createElement('div');
    d.className = 'ai-msg ' + cls;
    // Linkify URLs in bot messages so openUrl/share results stay clickable
    // even when the browser blocks popup opens.
    if (cls === 'bot' && typeof text === 'string' && text.indexOf('http') >= 0) {
      var parts = text.split(/(https?:\\/\\/[^\\s<>"')]+)/g);
      parts.forEach(function(part) {
        if (/^https?:\\/\\//.test(part)) {
          var a = document.createElement('a');
          a.href = part;
          a.target = '_top';
          a.rel = 'noopener noreferrer';
          a.textContent = part.length > 60 ? part.slice(0, 57) + '...' : part;
          a.style.color = '#3b7bd4';
          a.style.wordBreak = 'break-all';
          d.appendChild(a);
        } else if (part) {
          d.appendChild(document.createTextNode(part));
        }
      });
    } else {
      d.textContent = text;
    }
    msgsEl.appendChild(d);
    msgsEl.scrollTop = msgsEl.scrollHeight;
    return d;
  }

  function addCapture(dataUrl) {
    var d = document.createElement('div');
    d.className = 'ai-msg bot';
    var img = document.createElement('img');
    img.src = dataUrl;
    d.appendChild(img);
    msgsEl.appendChild(d);
    msgsEl.scrollTop = msgsEl.scrollHeight;
  }

  function updateKeyStatus() {
    try {
      var noKeyNeeded = (_provider === 'copilot' || _provider === 'agent');
      var hasAny = noKeyNeeded || !!(_apiKey || _serverHasKey);
      keyStatus.textContent = noKeyNeeded ? 'no key (bridge)' : (hasAny ? t('keySet') : t('noKeySet'));
      keyStatus.className = 'ai-key-status' + (hasAny ? ' ok' : '');
      // Expose where the active key comes from so users can judge exposure.
      var src = _apiKey ? _keySource : (_serverHasKey ? 'server proxy' : '');
      if (keySrcEl) keySrcEl.textContent = (!noKeyNeeded && src) ? (t('keySrc') + ': ' + src) : '';
      var warnEl = document.querySelector('.ai-key-warn');
      if (warnEl) warnEl.style.display = (noKeyNeeded || (_serverHasKey && !_apiKey) || _provider !== 'gemini') ? 'none' : '';
    } catch (e) {}
  }

  // ---------- tool execution ----------
  function callHostTool(name, args) {
    return new Promise(function(resolve) {
      var reqId = 't' + (++_reqSeq);
      var done = false;
      var timer = setTimeout(function() {
        if (done) return; done = true;
        delete _pendingTools[reqId];
        resolve({ error: t('timeout') });
      }, 40000);
      _pendingTools[reqId] = function(result) {
        if (done) return; done = true;
        clearTimeout(timer);
        resolve(result);
      };
      postToParent({ action: 'aiToolCall', reqId: reqId, name: name, args: args || {} });
    });
  }

  function toolSearchGsi(args) {
    var q = String((args && args.query) || '').trim();
    var limit = Math.max(1, Math.min(10, Number(args && args.limit) || 5));
    if (!q) return Promise.resolve({ error: 'query required' });
    var url = 'https://msearch.gsi.go.jp/address-search/AddressSearch?q=' + encodeURIComponent(q);
    return fetch(url).then(function(res) {
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res.json();
    }).then(function(data) {
      var src = Array.isArray(data) ? data : ((data && (data.features || data.results)) || []);
      var out = src.slice(0, limit).map(function(f) {
        var props = (f && f.properties) || {};
        var geom = (f && f.geometry) || {};
        var coords = geom.coordinates || null;
        return {
          name: f.name || props.title || props.name || '',
          address: props.address || props.title || '',
          lng: (coords && typeof coords[0] === 'number') ? coords[0] : null,
          lat: (coords && typeof coords[1] === 'number') ? coords[1] : null
        };
      }).filter(function(it) { return it.lat !== null && it.lng !== null; });
      return { results: out };
    }).catch(function(e) {
      return { error: 'search failed: ' + String(e && e.message || e) };
    });
  }

  function toolSearchYahoo(args) {
    var q = String((args && args.query) || '').trim();
    var limit = Math.max(1, Math.min(10, Number(args && args.limit) || 5));
    if (!q) return Promise.resolve({ error: 'query required' });
    // Same proxy as the Search tab: uses the server-side key when available,
    // otherwise falls back to the inspector-provided yahooAppId.
    return fetch('https://re-earth-geo-suite.vercel.app/api/yahoo-env').then(function(envRes) {
      return (envRes && envRes.ok) ? envRes.json() : {};
    }).catch(function() { return {}; }).then(function(envJson) {
      var serverHasAppId = !!(envJson && envJson.hasAppId);
      var rawId = String(window._yahooAppId || '').trim().replace(/^"+|"+$/g, '');
      var inspectorAppId = (rawId.length > 0 && !/^(YOUR_APP_ID|undefined|null)$/i.test(rawId) && !/あなた/.test(rawId)) ? rawId : null;
      if (!serverHasAppId && !inspectorAppId) return { error: 'yahooAppId not set (inspector) and no server key' };
      var url = 'https://re-earth-geo-suite.vercel.app/api/yahoo-search?query=' + encodeURIComponent(q) + (serverHasAppId ? '' : ('&appid=' + encodeURIComponent(inspectorAppId || '')));
      return fetch(url).then(function(res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.json();
      }).then(function(data) {
        var features = (data && data.Feature) ? data.Feature : [];
        var out = features.slice(0, limit).map(function(f) {
          var coords = (f && f.Geometry && f.Geometry.Coordinates) ? String(f.Geometry.Coordinates).split(',') : null;
          var lng = coords && coords.length > 0 ? Number(coords[0]) : null;
          var lat = coords && coords.length > 1 ? Number(coords[1]) : null;
          return {
            name: (f && (f.Name || f.name) || (f && f.Property && f.Property.Title) || ''),
            address: (f && f.Property && f.Property.Address) || '',
            lng: (typeof lng === 'number' && isFinite(lng)) ? lng : null,
            lat: (typeof lat === 'number' && isFinite(lat)) ? lat : null
          };
        }).filter(function(it) { return it.lat !== null && it.lng !== null; });
        return { results: out, provider: 'yahoo' };
      }).catch(function(e) {
        return { error: 'yahoo search failed: ' + String(e && e.message || e) };
      });
    });
  }

  function toolSearchLocation(args) {
    var provider = String((args && args.provider) || 'gsi').toLowerCase();
    if (provider === 'yahoo') return toolSearchYahoo(args);
    if (provider === 'auto') {
      return toolSearchYahoo(args).then(function(r) {
        return (r && r.results && r.results.length) ? r : toolSearchGsi(args);
      });
    }
    return toolSearchGsi(args);
  }

  // Markdown-lite renderer (port of kasugai renderMarkdownLite): escapes HTML
  // first, then applies headings/bold/italic/code/links/lists.
  function renderMarkdownLite(md) {
    var esc = String(md || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    var lines = esc.split(/\\r\\n|\\r|\\n/);
    var out = [], inList = false, inCode = false;
    var BT = String.fromCharCode(96); // backtick (a literal one would end the html template)
    function inline(s) {
      return s.replace(new RegExp(BT + '([^' + BT + ']+)' + BT, 'g'), '<code>$1</code>')
        .replace(/\\*\\*([^*]+)\\*\\*/g, '<b>$1</b>')
        .replace(/\\[([^\\]]+)\\]\\((https?:[^)\\s]+)\\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" style="color:#3b7bd4;">$1</a>');
    }
    lines.forEach(function(ln) {
      if (ln.replace(/^\\s*/, '').indexOf(BT + BT + BT) === 0) {
        if (inCode) { out.push('</code></pre>'); inCode = false; }
        else { if (inList) { out.push('</ul>'); inList = false; } out.push('<pre style="background:#f5f5f7;padding:8px;border-radius:6px;overflow:auto;font-size:0.78em;"><code>'); inCode = true; }
        return;
      }
      if (inCode) { out.push(ln + '\\n'); return; }
      var h = ln.match(/^(#{1,4})\\s+(.*)$/);
      if (h) { if (inList) { out.push('</ul>'); inList = false; } var lv = h[1].length; out.push('<div style="font-weight:700;font-size:' + (lv <= 1 ? '1.05em' : '0.95em') + ';margin:' + (lv <= 1 ? '8px' : '6px') + ' 0 4px;">' + inline(h[2]) + '</div>'); return; }
      var li = ln.match(/^\\s*[-*]\\s+(.*)$/);
      if (li) { if (!inList) { out.push('<ul style="margin:2px 0 6px;padding-left:18px;">'); inList = true; } out.push('<li>' + inline(li[1]) + '</li>'); return; }
      if (inList) { out.push('</ul>'); inList = false; }
      if (/^\\s*$/.test(ln)) { out.push('<div style="height:6px;"></div>'); return; }
      if (/^\\s*>/.test(ln)) { out.push('<div style="border-left:3px solid #ccc;padding-left:8px;color:#555;margin:4px 0;">' + inline(ln.replace(/^\\s*>\\s?/, '')) + '</div>'); return; }
      out.push('<div>' + inline(ln) + '</div>');
    });
    if (inList) out.push('</ul>');
    if (inCode) out.push('</code></pre>');
    return out.join('');
  }

  // Report modal (port of kasugai showReport): markdown/html overlay with
  // download + copy. The iframe sandbox may block downloads — clipboard copy
  // and an always-visible body are the fallback.
  function toolShowReport(args) {
    return new Promise(function(resolve) {
      try {
        var title = String((args && args.title) || 'Report');
        var md = (args && typeof args.markdown === 'string') ? args.markdown : null;
        var raw = (args && typeof args.html === 'string') ? args.html : null;
        if (md === null && raw === null) { resolve({ error: 'markdown or html required' }); return; }
        var old = document.getElementById('ai-report-modal'); if (old) old.remove();
        var wrap = document.createElement('div');
        wrap.id = 'ai-report-modal';
        wrap.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.45);z-index:99999;display:flex;align-items:center;justify-content:center;';
        var box = document.createElement('div');
        box.style.cssText = 'background:#fff;width:92%;max-height:88%;border-radius:8px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.35);';
        var head = document.createElement('div');
        head.style.cssText = 'display:flex;align-items:center;gap:6px;padding:6px 10px;border-bottom:1px solid #e3e3e3;background:#f7f9fc;';
        var ttl = document.createElement('div');
        ttl.textContent = title;
        ttl.style.cssText = 'flex:1;font-weight:600;font-size:0.85em;color:#333;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';
        head.appendChild(ttl);
        function mkBtn(label, fn) {
          var b = document.createElement('button');
          b.textContent = label;
          b.style.cssText = 'border:1px solid #ccc;background:#fff;border-radius:4px;padding:2px 8px;font-size:0.8em;cursor:pointer;';
          b.addEventListener('click', fn);
          head.appendChild(b);
          return b;
        }
        var body = document.createElement('div');
        body.style.cssText = 'padding:10px;overflow:auto;font-size:0.85em;line-height:1.5;color:#222;';
        body.innerHTML = (raw !== null) ? raw : renderMarkdownLite(md);
        var plain = (md !== null) ? md : body.textContent || '';
        mkBtn('\\u2B07', function() {
          try {
            var blob = new Blob([(md !== null) ? md : ('<!DOCTYPE html><html><body>' + (raw || '') + '<\\/body><\\/html>')], { type: (md !== null) ? 'text/markdown' : 'text/html' });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = (title || 'report').replace(/[^\\w.-]+/g, '_') + ((md !== null) ? '.md' : '.html');
            document.body.appendChild(a); a.click(); a.remove();
            setTimeout(function() { try { URL.revokeObjectURL(a.href); } catch (e) {} }, 5000);
          } catch (e) { try { navigator.clipboard.writeText(plain); } catch (_) {} }
        });
        mkBtn('\\u2398', function() { try { navigator.clipboard.writeText(plain); } catch (e) { try { window.getSelection().selectAllChildren(body); } catch (_) {} } });
        mkBtn('\\u00D7', function() { wrap.remove(); resolve({ ok: true, title: title, closed: true }); });
        wrap.appendChild(box); box.appendChild(head); box.appendChild(body);
        wrap.addEventListener('click', function(ev) { if (ev.target === wrap) { wrap.remove(); resolve({ ok: true, title: title, closed: true }); } });
        document.body.appendChild(wrap);
        resolve({ ok: true, title: title, format: (md !== null) ? 'markdown' : 'html', chars: plain.length });
      } catch (e) { resolve({ error: 'showReport failed: ' + String(e) }); }
    });
  }

  function toolFlyToCurrentLocation() {
    return new Promise(function(resolve) {
      if (!navigator.geolocation) { resolve({ error: 'geolocation unavailable in this context' }); return; }
      navigator.geolocation.getCurrentPosition(function(pos) {
        callHostTool('flyTo', { lat: pos.coords.latitude, lng: pos.coords.longitude, height: 2000 }).then(function(r) {
          if (r && !r.error) r.accuracy = pos.coords.accuracy;
          resolve(r);
        });
      }, function(err) {
        resolve({ error: 'geolocation failed: ' + String(err && err.message || err) });
      }, { timeout: 10000, enableHighAccuracy: false });
    });
  }

  function toolFlyToUrl(args) {
    var raw = String((args && args.url) || '').trim();
    if (!raw) return Promise.resolve({ error: 'url required' });
    var q = raw.indexOf('?') >= 0 ? raw.slice(raw.indexOf('?')) : raw;
    var m = {};
    try { q.replace(/[?&#]([a-zA-Z_][a-zA-Z0-9_]*)=([^&#]*)/g, function(_, k, v) { try { m[k.toLowerCase()] = decodeURIComponent(v); } catch (e) { m[k.toLowerCase()] = v; } return ''; }); } catch (e) {}
    var lat = parseFloat(m.lat);
    var lng = parseFloat(m.lng !== undefined ? m.lng : m.lon);
    if (!isFinite(lat) || !isFinite(lng)) return Promise.resolve({ error: 'no lat/lng found in url' });
    var fargs = { lat: lat, lng: lng };
    ['height', 'heading', 'pitch'].forEach(function(k) {
      var v = parseFloat(m[k]);
      if (isFinite(v)) fargs[k] = v;
    });
    return callHostTool('flyTo', fargs);
  }

  function makeApi() {
    var api = {};
    API_METHODS.forEach(function(n) {
      api[n] = function(args) { return callHostTool(n, args || {}); };
    });
    api.searchLocation = function(a) { return toolSearchLocation(typeof a === 'string' ? { query: a } : a); };
    api.showReport = function(a) { return toolShowReport(a || {}); };
    api.flyToUrl = function(a) { return toolFlyToUrl(typeof a === 'string' ? { url: a } : a); };
    api.flyToCurrentLocation = function() { return toolFlyToCurrentLocation(); };
    return api;
  }

  function toolRunCode(args) {
    return new Promise(function(resolve) {
      var code = String((args && args.code) || '');
      var done = false;
      var timer = setTimeout(function() {
        if (done) return; done = true;
        resolve({ error: 'runCode timeout (20s)' });
      }, 20000);
      try {
        var fn = new Function('api', 'fetch', '"use strict"; return (async function(){ ' + code + ' })();');
        Promise.resolve(fn(makeApi(), fetch.bind(window))).then(function(v) {
          if (done) return; done = true;
          clearTimeout(timer);
          resolve({ result: v === undefined ? null : v });
        }).catch(function(e) {
          if (done) return; done = true;
          clearTimeout(timer);
          resolve({ error: String(e && e.message || e) });
        });
      } catch (e) {
        if (done) return; done = true;
        clearTimeout(timer);
        resolve({ error: String(e && e.message || e) });
      }
    });
  }

  function executeTool(name, args) {
    if (name === 'searchLocation') return toolSearchLocation(args);
    if (name === 'showReport') return toolShowReport(args);
    if (name === 'flyToUrl') return toolFlyToUrl(args);
    if (name === 'flyToCurrentLocation') return toolFlyToCurrentLocation();
    if (name === 'runCode') return toolRunCode(args);
    return callHostTool(name, args);
  }

  // ---------- Gemini loop ----------
  function trimHistory() {
    // Keep the conversation bounded; drop oldest turns (never leave a dangling
    // functionCall/functionResponse pair at the cut boundary is best-effort).
    var MAX = 40;
    while (_history.length > MAX) _history.shift();
  }

  // When the hosting site provides a server-side key (GEMINI_API_KEY env on
  // the Vercel deployment), prefer /api/gemini so no key ever reaches the
  // browser. Otherwise fall back to the visitor's own key via a direct call.
  var PROXY_BASE = 'https://re-earth-geo-suite.vercel.app';
  var _serverKeyChecked = false;
  var _serverHasKey = false;
  function probeServerKey() {
    _serverKeyChecked = true;
    return fetch(PROXY_BASE + '/api/gemini-env').then(function(res) {
      return res.ok ? res.json() : {};
    }).then(function(j) {
      _serverHasKey = !!(j && j.hasKey);
      return _serverHasKey;
    }).catch(function() {
      _serverHasKey = false;
      return false;
    });
  }
  function ensureServerKey() {
    return _serverKeyChecked ? Promise.resolve(_serverHasKey) : probeServerKey();
  }

  function postGemini(bodyObj) {
    if (_serverHasKey) {
      return fetch(PROXY_BASE + '/api/gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: _model, request: bodyObj })
      }).then(function(res) {
        return res.json().then(function(data) {
          if (!res.ok) throw new Error((data && data.error && data.error.message) || ('HTTP ' + res.status));
          return data;
        });
      }).catch(function(e) {
        // Proxy failed (network or quota) — retry once against Google directly
        // when the visitor has a key of their own.
        if (_apiKey) { _serverHasKey = false; return postGemini(bodyObj); }
        throw e;
      });
    }
    var endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(_model) + ':generateContent?key=' + encodeURIComponent(_apiKey);
    return fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(bodyObj)
    }).then(function(res) {
      return res.json().then(function(data) {
        if (!res.ok) throw new Error((data && data.error && data.error.message) || ('HTTP ' + res.status));
        return data;
      });
    });
  }

  // --- generic provider loop (OpenAI-compatible / Anthropic / external agent) ---
  // Neutral transcript for non-Gemini providers: entries are
  // {role:'user',text} / {role:'assistant',text,calls:[{id,name,args}]} / {role:'tool',id,name,result}
  var _pxHist = [];
  function pxSchema(s) {
    if (!s || typeof s !== 'object') return s;
    var out = Array.isArray(s) ? [] : {};
    for (var k in s) {
      var v = s[k];
      out[k] = (k === 'type' && typeof v === 'string') ? v.toLowerCase()
        : (typeof v === 'object' ? pxSchema(v) : v);
    }
    return out;
  }
  function pxToolDecls(kind) {
    return (TOOL_DECLS || []).map(function(d) {
      if (kind === 'anthropic') return { name: d.name, description: d.description, input_schema: pxSchema(d.parameters || { type: 'object' }) };
      return { type: 'function', function: { name: d.name, description: d.description, parameters: pxSchema(d.parameters || { type: 'object' }) } };
    });
  }
  function pxTrunc(v) { var s = JSON.stringify(v === undefined ? null : v); return s.length > 4000 ? s.slice(0, 4000) : s; }
  function pxMsgsOpenAi() {
    return _pxHist.map(function(m) {
      if (m.role === 'user') return { role: 'user', content: m.text };
      if (m.role === 'assistant') return { role: 'assistant', content: m.text || null,
        tool_calls: (m.calls || []).map(function(c) { return { id: c.id, type: 'function', function: { name: c.name, arguments: JSON.stringify(c.args || {}) } }; }) };
      return { role: 'tool', tool_call_id: m.id, name: m.name, content: pxTrunc(m.result) };
    });
  }
  function pxMsgsAnthropic() {
    return _pxHist.map(function(m) {
      if (m.role === 'user') return { role: 'user', content: m.text };
      if (m.role === 'assistant') {
        var c = [];
        if (m.text) c.push({ type: 'text', text: m.text });
        (m.calls || []).forEach(function(t) { c.push({ type: 'tool_use', id: t.id, name: t.name, input: t.args || {} }); });
        return { role: 'assistant', content: c };
      }
      return { role: 'user', content: [{ type: 'tool_result', tool_use_id: m.id, content: pxTrunc(m.result) }] };
    });
  }
  function pxRunCalls(calls, log, nextRound) {
    var chain = Promise.resolve();
    calls.forEach(function(c) {
      chain = chain.then(function() {
        addMsg('tool', t('tool') + ': ' + c.name + ' ' + JSON.stringify(c.args).slice(0, 120));
        return executeTool(c.name, c.args || {}).then(function(result) {
          log.push({ role: 'tool', id: c.id, name: c.name, result: result });
        });
      });
    });
    return chain.then(nextRound);
  }
  function callOpenAICompat() {
    var isAzure = _provider === 'azure';
    var endpoint = ((endpointInput && endpointInput.value) || '').trim() || (isAzure ? '' : 'https://api.openai.com');
    if (!endpoint) return Promise.reject(new Error('endpoint required'));
    var url = isAzure
      ? endpoint.replace(/[/]+$/, '') + '/openai/deployments/' + encodeURIComponent(_model) + '/chat/completions?api-version=' + encodeURIComponent((apiverInput && apiverInput.value || '').trim() || '2024-10-21')
      : endpoint.replace(/[/]+$/, '') + '/v1/chat/completions';
    var headers = { 'Content-Type': 'application/json' };
    if (isAzure) headers['api-key'] = _apiKey; else headers['Authorization'] = 'Bearer ' + _apiKey;
    var step = 0;
    function next() {
      if (++step > 8) return { done: true, text: t('stepLimit') };
      return fetch(url, { method: 'POST', headers: headers, body: JSON.stringify({
        model: _model, messages: pxMsgsOpenAi(), tools: pxToolDecls('openai'), tool_choice: 'auto'
      }) }).then(function(res) {
        return res.json().then(function(data) {
          if (!res.ok) throw new Error((data && data.error && data.error.message) || ('HTTP ' + res.status));
          var msg = (data && data.choices && data.choices[0] && data.choices[0].message) || {};
          var calls = (msg.tool_calls || []).map(function(tc) {
            var a = {}; try { a = JSON.parse(tc.function && tc.function.arguments || '{}'); } catch (e) {}
            return { id: tc.id, name: tc.function && tc.function.name, args: a };
          }).filter(function(c) { return c.name; });
          _pxHist.push({ role: 'assistant', text: msg.content || '', calls: calls });
          if (!calls.length) return { done: true, text: (msg.content || '').trim() };
          return pxRunCalls(calls, _pxHist, next);
        });
      });
    }
    return next();
  }
  function callAnthropic() {
    var endpoint = ((endpointInput && endpointInput.value) || '').trim() || 'https://api.anthropic.com';
    var url = endpoint.replace(/[/]+$/, '') + '/v1/messages';
    var step = 0;
    function next() {
      if (++step > 8) return { done: true, text: t('stepLimit') };
      return fetch(url, { method: 'POST', headers: {
        'Content-Type': 'application/json', 'x-api-key': _apiKey,
        'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true'
      }, body: JSON.stringify({
        model: _model, max_tokens: 2048, system: SYSTEM_INSTRUCTION,
        messages: pxMsgsAnthropic(), tools: pxToolDecls('anthropic')
      }) }).then(function(res) {
        return res.json().then(function(data) {
          if (!res.ok) throw new Error((data && data.error && data.error.message) || ('HTTP ' + res.status));
          var blocks = (data && data.content) || [];
          var text = blocks.filter(function(b) { return b && b.type === 'text'; }).map(function(b) { return b.text; }).join('').trim();
          var calls = blocks.filter(function(b) { return b && b.type === 'tool_use'; }).map(function(b) { return { id: b.id, name: b.name, args: b.input || {} }; });
          _pxHist.push({ role: 'assistant', text: text, calls: calls });
          if (!calls.length) return { done: true, text: text };
          return pxRunCalls(calls, _pxHist, next);
        });
      });
    }
    return next();
  }
  // CANVAS bridge-hub contract: POST /agent {provider,model,message,camera,
  // layers,basemaps,history,tools} -> {reply,actions:[{name,args}]}
  var _hubDetected = null;
  // Explicit endpoint wins; otherwise probe bridge-hub.exe on port 8511
  // (CANVAS spec: unified to 8511 only).
  function detectHub() {
    if (_hubDetected) return Promise.resolve(_hubDetected);
    var ep = ((endpointInput && endpointInput.value) || '').trim();
    if (ep) {
      _hubDetected = ep.replace(/[/]+agent[\/]?$/, '');
      return Promise.resolve(_hubDetected);
    }
    var ports = [8511];
    function probe(i) {
      if (i >= ports.length) return Promise.reject(new Error('hub not found on 8511'));
      return fetch('http://127.0.0.1:' + ports[i] + '/health', { cache: 'no-store' }).then(function(r) {
        if (r && r.ok) { _hubDetected = 'http://127.0.0.1:' + ports[i]; return _hubDetected; }
        return probe(i + 1);
      }).catch(function() { return probe(i + 1); });
    }
    return probe(0);
  }
  function callAgent(text) {
    var prov = (_provider === 'copilot') ? 'copilot' : 'agent';
    return detectHub().then(function(url) {
      return fetch(url + '/agent', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        provider: prov,
        model: _model || undefined,
        message: text,
        project: 'default',
        camera: null, layers: [], basemaps: [],
        history: _pxHist.slice(-20).map(function(m) { return { role: m.role, text: m.text || '' }; }),
        tools: TOOL_DECLS || []
      })
    }).then(function(res) {
      return res.json().then(function(data) {
        if (!res.ok) throw new Error((data && (data.error || data.message)) || ('HTTP ' + res.status));
        var actions = (data && data.actions) || [];
        var chain = Promise.resolve();
        actions.forEach(function(a) {
          chain = chain.then(function() {
            addMsg('tool', t('tool') + ': ' + a.name + ' ' + JSON.stringify(a.args || {}).slice(0, 120));
            return executeTool(a.name, a.args || {});
          });
        });
        return chain.then(function() {
          return { done: true, text: (data && (data.reply || data.text)) || (actions.length ? '' : t('noResponse')) };
        });
      });
    });
    });
  }
  // Populate the model datalist from the provider's /models endpoint
  // (CANVAS-style: the list reflects what the credential/endpoint advertises).
  function refreshProviderModels() {
    var dl = document.getElementById('ai-model-list');
    var st = document.getElementById('ai-hub-status');
    if (!dl || !st) return;
    var pv = _provider;
    function fill(models, note) {
      dl.innerHTML = '';
      (models || []).forEach(function(m) {
        var o = document.createElement('option');
        o.value = m.id || m.name || m; dl.appendChild(o);
      });
      st.style.display = '';
      st.textContent = note;
    }
    if (pv === 'copilot') {
      st.textContent = 'hub: fetching models...';
      detectHub().then(function(base) {
        return fetch(base + '/models?provider=copilot').then(function(r) { return r.json(); });
      }).then(function(d) {
        var ms = (d && d.models) || [];
        fill(ms, (d && d.fallback) || !ms.length ? 'hub: connected, but no model list (not signed in?)' : 'hub: ' + ms.length + ' models');
      }).catch(function() { st.style.display = ''; st.textContent = 'hub: unreachable — install/start bridge-hub.exe (port 8511)'; });
      return;
    }
    if (pv === 'openai' || pv === 'anthropic') {
      if (!_apiKey) { fill([], 'models: enter API key first'); return; }
      var base = (((endpointInput && endpointInput.value) || '').trim()
        || (pv === 'anthropic' ? 'https://api.anthropic.com' : 'https://api.openai.com')).replace(/[/]+$/, '');
      var headers = pv === 'anthropic'
        ? { 'x-api-key': _apiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' }
        : { 'Authorization': 'Bearer ' + _apiKey };
      st.textContent = 'models: fetching...';
      fetch(base + '/v1/models', { headers: headers }).then(function(r) {
        return r.json().then(function(d) {
          if (!r.ok) throw new Error((d && d.error && d.error.message) || ('HTTP ' + r.status));
          var ms = (d && d.data) || [];
          fill(ms, ms.length ? ('models: ' + ms.length) : 'models: none listed');
        });
      }).catch(function(e) { st.style.display = ''; st.textContent = 'models: ' + String(e && e.message || e); });
      return;
    }
    st.style.display = 'none';
  }

  function callGemini() {
    var maxSteps = 8;
    var step = 0;
    function next() {
      trimHistory();
      return postGemini({
        systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
        contents: _history,
        tools: TOOL_DECLS
      }).then(function(data) {
        var parts = (data && data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts) || [];
        _history.push({ role: 'model', parts: parts });
        var calls = parts.filter(function(p) { return p && p.functionCall; });
        if (!calls.length) {
          var text = parts.map(function(p) { return (p && p.text) || ''; }).join('').trim();
          return { done: true, text: text };
        }
        if (++step > maxSteps) {
          return { done: true, text: t('stepLimit') };
        }
        var responseParts = [];
        var chain = Promise.resolve();
        calls.forEach(function(part) {
          chain = chain.then(function() {
            var fc = part.functionCall;
            var fname = fc.name;
            var fargs = fc.args || {};
            addMsg('tool', t('tool') + ': ' + fname + ' ' + JSON.stringify(fargs).slice(0, 120));
            return executeTool(fname, fargs).then(function(result) {
              if (fname === 'captureView' && result && result.dataUrl) addCapture(result.dataUrl);
              responseParts.push({ functionResponse: { name: fname, response: { result: result } } });
            });
          });
        });
        return chain.then(function() {
          _history.push({ role: 'user', parts: responseParts });
          return next();
        });
      });
    }
    return next();
  }

  function submit(text) {
    if (_busy) return;
    _busy = true;
    sendBtn.disabled = true;
    var thinking = addMsg('sys', '…');
    var p;
    if (_provider === 'openai' || _provider === 'azure') {
      _pxHist.push({ role: 'user', text: text });
      p = callOpenAICompat();
    } else if (_provider === 'anthropic') {
      _pxHist.push({ role: 'user', text: text });
      p = callAnthropic();
    } else if (_provider === 'agent' || _provider === 'copilot') {
      p = callAgent(text);
    } else {
      _history.push({ role: 'user', parts: [{ text: text }] });
      p = callGemini();
    }
    p.then(function(res) {
      try { thinking.remove(); } catch (e) {}
      var out = (res && res.text) ? res.text : t('noResponse');
      addMsg('bot', out);
      if (_chatReplyCb) { var cb = _chatReplyCb; _chatReplyCb = null; cb({ reply: out }); }
    }).catch(function(e) {
      try { thinking.remove(); } catch (e2) {}
      var et = t('err') + ': ' + String(e && e.message || e);
      addMsg('bot', et);
      if (_chatReplyCb) { var cb2 = _chatReplyCb; _chatReplyCb = null; cb2({ error: et }); }
    }).then(function() {
      _busy = false;
      sendBtn.disabled = false;
      try { inputEl.focus(); } catch (e) {}
    });
  }

  function doSend() {
    var text = (inputEl.value || '').trim();
    if (!text) return;
    inputEl.value = '';
    addMsg('user', text);
    var needKey = (_provider !== 'copilot' && _provider !== 'agent');
    if (needKey && !_apiKey && !_serverHasKey) {
      ensureServerKey().then(function() {
        if (_serverHasKey || _apiKey) submit(text);
        else addMsg('sys', t('noKey'));
      });
      return;
    }
    submit(text);
  }
  form.addEventListener('submit', function(ev) { ev.preventDefault(); });
  sendBtn.addEventListener('click', function() { doSend(); });
  inputEl.addEventListener('keydown', function(ev) {
    if (ev.key === 'Enter' && !ev.isComposing) { ev.preventDefault(); doSend(); }
  });

  document.getElementById('ai-settings-btn').addEventListener('click', function() {
    var root = document.querySelector('.ai-wrap');
    if (root && root.classList.contains('minimized')) { _userToggledMin = true; setMinimized(false); }
    settingsPanel.classList.toggle('open');
  });
  document.getElementById('ai-clear-btn').addEventListener('click', function() {
    _history = [];
    msgsEl.innerHTML = '';
    addMsg('sys', t('cleared'));
  });
  function setMinimized(min) {
    var root = document.querySelector('.ai-wrap');
    var btn = document.getElementById('ai-min-btn');
    if (!root) return;
    if (min) root.classList.add('minimized'); else root.classList.remove('minimized');
    if (btn) {
      btn.setAttribute('data-i18n-title', min ? 'restore' : 'minimize');
      btn.title = t(min ? 'restore' : 'minimize');
    }
  }
  function autoMinimize() {
    if (_userToggledMin || !_configReceived || !_serverKeyChecked) return;
    setMinimized(!(_apiKey || _serverHasKey));
  }
  document.getElementById('ai-min-btn').addEventListener('click', function() {
    _userToggledMin = true;
    var root = document.querySelector('.ai-wrap');
    setMinimized(!(root && root.classList.contains('minimized')));
  });
  document.getElementById('ai-save').addEventListener('click', function(ev) {
    ev.preventDefault();
    var k = (keyInput.value || '').trim();
    postToParent({ action: 'aiSetApiKey', key: k, persist: !!(rememberEl && rememberEl.checked) });
    var m = (modelInput.value || '').trim();
    if (m && m !== _model) postToParent({ action: 'aiSetModel', model: m });
    postToParent({ action: 'aiSetProvider', persist: !!(rememberEl && rememberEl.checked), provider: {
      provider: providerSel ? providerSel.value : 'gemini',
      endpoint: (endpointInput && endpointInput.value || '').trim(),
      apiVer: (apiverInput && apiverInput.value || '').trim(),
      agentModel: (agentModelInput && agentModelInput.value || '').trim()
    } });
    saveMsg.textContent = t('saved');
    setTimeout(function() { saveMsg.textContent = ''; }, 2000);
  });

  window.addEventListener('message', function(e) {
    try {
      var msg = e && e.data;
      if (!msg || !msg.action) return;
      if (msg.action === 'aiToolResult') {
        var p = _pendingTools[msg.reqId];
        if (p) { delete _pendingTools[msg.reqId]; p(msg.result); }
      } else if (msg.action === 'aiChatCmd') {
        // External/bridge control of this chat panel.
        var cmd = String(msg.cmd || ''), rid = msg.reqId, aa = msg.args || {};
        if (cmd === 'aiChatStatus') {
          postToParent({ action: 'aiChatResult', reqId: rid, result: {
            provider: _provider, model: _model,
            hasKey: !!(_apiKey || _serverHasKey), busy: !!_busy,
            endpoint: endpointInput ? endpointInput.value : ''
          } });
        } else if (cmd === 'aiChatSet') {
          var persist = aa.persist === false ? false : true;
          if (providerSel && typeof aa.provider === 'string' && aa.provider) { providerSel.value = aa.provider; applyProviderFields(); }
          if (endpointInput && aa.endpoint !== undefined) { endpointInput.value = aa.endpoint; _hubDetected = null; }
          if (modelInput && aa.model !== undefined) modelInput.value = aa.model;
          if (apiverInput && aa.apiVer !== undefined) apiverInput.value = aa.apiVer;
          if (agentModelInput && aa.agentModel !== undefined) agentModelInput.value = aa.agentModel;
          if (aa.apiKey !== undefined) postToParent({ action: 'aiSetApiKey', key: String(aa.apiKey), persist: persist });
          postToParent({ action: 'aiSetProvider', persist: persist, provider: {
            provider: providerSel ? providerSel.value : 'gemini',
            endpoint: (endpointInput && endpointInput.value || '').trim(),
            apiVer: (apiverInput && apiverInput.value || '').trim(),
            agentModel: (agentModelInput && agentModelInput.value || '').trim()
          } });
          postToParent({ action: 'aiChatResult', reqId: rid, result: { ok: true, provider: _provider } });
        } else if (cmd === 'aiChatSend') {
          _chatReplyCb = function(reply) { postToParent({ action: 'aiChatResult', reqId: rid, result: reply }); };
          setTimeout(function() { if (_chatReplyCb) { var c = _chatReplyCb; _chatReplyCb = null; c({ error: 'chat timeout' }); } }, 120000);
          inputEl.value = String(aa.text || '');
          doSend();
        }
      } else if (msg.action === 'aiConfig') {
        _apiKey = (typeof msg.apiKey === 'string') ? msg.apiKey : '';
        _keySource = msg.keySource || 'none';
        if (typeof msg.model === 'string' && msg.model) _model = msg.model;
        window._yahooAppId = (typeof msg.yahooAppId === 'string') ? msg.yahooAppId : '';
        window._googleMapsApiKey = (typeof msg.googleMapsApiKey === 'string') ? msg.googleMapsApiKey : '';
        if (msg.provider && typeof msg.provider === 'object') {
          var pv = msg.provider;
          if (providerSel && typeof pv.provider === 'string' && pv.provider) providerSel.value = pv.provider;
          if (endpointInput && typeof pv.endpoint === 'string') endpointInput.value = pv.endpoint;
          if (apiverInput && typeof pv.apiVer === 'string') apiverInput.value = pv.apiVer;
          if (agentModelInput && typeof pv.agentModel === 'string') agentModelInput.value = pv.agentModel;
          applyProviderFields();
        }
        // inspector "aiHub:" line pre-fills the Copilot/agent endpoint when unset
        if (typeof msg.aiHub === 'string' && msg.aiHub && endpointInput && !endpointInput.value.trim()) {
          endpointInput.value = msg.aiHub;
          _hubDetected = null;
        }
        if (msg.i18n && typeof msg.i18n === 'object') {
          for (var lk in msg.i18n) { try { GEO_I18N[lk] = msg.i18n[lk]; } catch (e) {} }
          applyI18n(); updateKeyStatus();
        }
        if (rememberEl) rememberEl.checked = (_keySource === 'storage');
        if (_keySource !== 'inspector') keyInput.value = _apiKey;
        modelInput.value = _model;
        if (_provider === 'copilot' && /^gemini-/.test(modelInput.value)) modelInput.value = '';
        updateKeyStatus();
        _configReceived = true;
        autoMinimize();
        if (msg.lang) {
          window._GEO_LANG_CONF = String(msg.lang);
          var nl = resolveLang();
          if (nl !== GEO_LANG) { GEO_LANG = nl; applyI18n(); updateKeyStatus(); }
        }
      } else if (msg.action === 'lang') {
        window._GEO_LANG_CONF = String(msg.lang || 'auto');
        var nl2 = resolveLang();
        if (nl2 !== GEO_LANG) { GEO_LANG = nl2; applyI18n(); updateKeyStatus(); }
      }
    } catch (e) {}
  });

  // init
  try { window.__aiExecuteTool = executeTool; } catch (e) {} // debug/test handle (same convention as window._fly)
  addMsg('sys', t('welcome'));
  updateKeyStatus();
  probeServerKey().then(function() { try { updateKeyStatus(); autoMinimize(); } catch (e) {} });
  postToParent({ action: 'aiGetConfig' });
  setTimeout(function() { postToParent({ action: 'aiGetConfig' }); }, 3000);
})();
</script>
`;
try {
    if (typeof reearth !== 'undefined' && reearth && reearth.ui && typeof reearth.ui.show === 'function') {
        reearth.ui.show(html, { width: 320, visible: true, extended: true });
    }
}
catch (e) { }
