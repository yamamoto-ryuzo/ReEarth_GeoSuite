reearth.ui.show(`
  <style>
  /* Generic styling system that provides consistent UI components and styling across all plugins */

  @import url("https://reearth.github.io/visualizer-plugin-sample-data/public/css/preset-ui.css");
  </style>
  <div class="primary-background text-center p-16 rounded-sm">
    <p class="text-3xl font-bold">Hello World</p>
  </div>
`);